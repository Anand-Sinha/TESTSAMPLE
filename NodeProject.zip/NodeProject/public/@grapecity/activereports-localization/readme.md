# ActiveReportsJS Localization

This package is a part of the [ActiveReportsJS](https://www.npmjs.com/package/@grapecity/activereports) and provides language resources for ARJS Viewer and Designer Components

Supported languages are: Japanese '`ja`', Chinese '`zh`', Korean '`ko`', Dutch '`nl`', German '`de`', Italian '`it`', Brazilian Portuguese '`pt-BR`'.

## Installation and Usage

Install ARJS Localization package

```bash
npm install @grapecity/activereports-localization
```
# ActiveReportsJS Viewer
1. Add reference to localization package

using html script tag:
```html
<script type="text/javascript" src="./dist/ar-js-locales.js"></script>
```

or import:
```javascript
import '@grapecity/activereports-localization';
```

2. Pass necessary language to viewer using `language` property:

```javascript
var viewer = new ActiveReports.Viewer("#root", { language: "ja" })
```
or in components
```javascript
<Viewer language="ja"/>
```
3. Also you can pass `language` property to `PageReport` ctr (can be used in exporting/printing reports without viewer):

```javascript
var pageReport = new ARJS.PageReport({ language: "ja" });
```
# ActiveReportsJS Designer

1. Add reference to localization package

using html script tag:
```html
<script type="text/javascript" src="./dist/designer/ja-locale.js"></script>
```

2. Pass necessary language to designer using `language` property:

```javascript
 var designer = new GC.ActiveReports.ReportDesigner.Designer("#designer-host", { language: "ja" });
```

## Documentation
For more information on how to use ActiveReportsJS and available tools, refer to the [Documentation](https://www.grapecity.com/activereportsjs/docs/) or [API reference](https://www.grapecity.com/activereportsjs/api/) for guidance.
