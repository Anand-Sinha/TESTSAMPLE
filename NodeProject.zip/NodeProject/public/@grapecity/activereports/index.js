module.exports.Core = require( './dist/@grapecity/ar-js-pagereport.js');
module.exports.ReportViewer = require('./lib/dist/rapecity/ar-js-viewer.js');
module.exports.HtmlExport = require( './dist/ode_modules/@grapecity/ar-js-html.js');
module.exports.XlsxExport = require( './dist/@grapecity/ar-js-xlsx.js');
module.exports.TabularDataExport = require( './dist/@grapecity/ar-js-tabular-data.js');
module.exports.PdfExport  = require( './dist/@grapecity/ar-js-pdf.js');
