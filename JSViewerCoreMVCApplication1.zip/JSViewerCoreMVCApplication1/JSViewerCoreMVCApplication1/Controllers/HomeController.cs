﻿using GrapeCity.ActiveReports;
using GrapeCity.ActiveReports.Export.Pdf.Page;
using GrapeCity.ActiveReports.PageReportModel;
using GrapeCity.ActiveReports.Rendering.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;

namespace JSViewerCoreMVCApplication1
{
    [Route("/")]
    public class HomeController : Controller
    {
        private IHostingEnvironment _env;

        public HomeController(IHostingEnvironment env)
        {
            _env = env;
        }
        public object Index() => Resource("index.html");

        [HttpGet("{file}")]
        public object Resource(string file)
        {
            var stream = GetType().Assembly.GetManifestResourceStream("JSViewerCoreMVCApplication1.wwwroot." + file);
            if (stream == null)
                return new NotFoundResult();

            if (Path.GetExtension(file) == ".html")
                return new ContentResult() { Content = new StreamReader(stream).ReadToEnd(), ContentType = "text/html" };

            if (Path.GetExtension(file) == ".ico")
                using (var memoryStream = new MemoryStream())
                {
                    stream.CopyTo(memoryStream);
                    return new FileContentResult(memoryStream.ToArray(), "image/x-icon") { FileDownloadName = file };
                }

            using (var streamReader = new StreamReader(stream))
                return new FileContentResult(System.Text.Encoding.UTF8.GetBytes(streamReader.ReadToEnd()), GetType(file)) { FileDownloadName = file };
        }

        private string GetType(string file)
        {
            if (file.EndsWith(".css"))
                return "text/css";

            if (file.EndsWith(".js"))
                return "text/javascript";

            return "text/html";
        }

        [HttpGet("reports")]
        public ActionResult Reports()
        {
            string[] validExtensions = { ".rdl", ".rdlx", ".rdlx-master" };

            return new ObjectResult(
                typeof(HomeController).Assembly.GetManifestResourceNames()
                .Where(x => x.StartsWith(Startup.EmbeddedReportsPrefix) && validExtensions.Any(ext => x.EndsWith(ext, StringComparison.InvariantCultureIgnoreCase)))
                .Select(x => x.Substring(Startup.EmbeddedReportsPrefix.Length + 1))
                .ToArray());
        }

        [HttpGet("exportSingle")]
        public FileResult ExportSingle()
        {
            System.Xml.XmlTextReader xtr = new System.Xml.XmlTextReader(_env.WebRootPath + "/Reports/SectionReport2.rpx");
            SectionReport report = new SectionReport();
            report.LoadLayout(xtr);
            xtr.Close();

            report.Run();

            GrapeCity.ActiveReports.Export.Pdf.Section.PdfExport pdfExport = new GrapeCity.ActiveReports.Export.Pdf.Section.PdfExport();
            pdfExport.Export(report.Document, _env.WebRootPath + "/MyPDF.pdf");

            string ReportURL = _env.WebRootPath + "/MyPDF.pdf";
            byte[] FileBytes = System.IO.File.ReadAllBytes(ReportURL);
            return File(FileBytes, "application/pdf");
        }

        [HttpGet("export")]
        public FileResult Export() 
        {
            System.Xml.XmlTextReader xtr = new System.Xml.XmlTextReader(_env.WebRootPath + "/Reports/SectionReport2.rpx");
            SectionReport report = new SectionReport();
            report.LoadLayout(xtr);
            xtr.Close();

            System.Xml.XmlTextReader xtr2 = new System.Xml.XmlTextReader(_env.WebRootPath + "/Reports/SectionReport2.rpx");
            SectionReport report2 = new SectionReport();
            report2.LoadLayout(xtr2);
            xtr2.Close();

            System.Xml.XmlTextReader xtr3 = new System.Xml.XmlTextReader(_env.WebRootPath + "/Reports/SectionReport2.rpx");
            SectionReport report3 = new SectionReport();
            report3.LoadLayout(xtr3);
            xtr3.Close();

            report.Run();
            report2.Run();
            report3.Run();

            report.Document.Pages.AddRange(report2.Document.Pages);
            report.Document.Pages.AddRange(report3.Document.Pages);

            GrapeCity.ActiveReports.Export.Pdf.Section.PdfExport pdfExport = new GrapeCity.ActiveReports.Export.Pdf.Section.PdfExport();
            pdfExport.Export(report.Document, _env.WebRootPath + "/MyMergedPDF.pdf");

            string ReportURL = _env.WebRootPath + "/MyMergedPDF.pdf";
            byte[] FileBytes = System.IO.File.ReadAllBytes(ReportURL);
            return File(FileBytes, "application/pdf");
        }
    }
}
