using System;
using System.IO;
using System.Linq;

using GrapeCity.ActiveReports;
using GrapeCity.ActiveReports.Export.Pdf.Section;
using GrapeCity.ActiveReports.SectionReportModel;

var cacheDirectory = Path.Combine(Path.GetTempPath(), $"ActiveReportsCache_{Guid.NewGuid():N}");
Directory.CreateDirectory(cacheDirectory);

var outputDirectory = Path.Combine(AppContext.BaseDirectory, "output");
Directory.CreateDirectory(outputDirectory);
var outputFilePath = Path.Combine(outputDirectory, "blank-report.pdf");

using var report = CreateBlankReport();

report.Document.CacheToDiskLocation = cacheDirectory;
report.Document.CacheToDisk = true;
report.Run(false);

var exporter = new PdfExport();
using var memoryStream = new MemoryStream();
exporter.Export(report.Document, memoryStream);

File.WriteAllBytes(outputFilePath, memoryStream.ToArray());

var cacheFiles = Directory.EnumerateFiles(cacheDirectory, "*", SearchOption.AllDirectories).ToArray();

Console.WriteLine($"CacheToDisk: {report.Document.CacheToDisk}");
Console.WriteLine($"CacheToDiskLocation: {report.Document.CacheToDiskLocation}");
Console.WriteLine($"Generated PDF path: {outputFilePath}");

static SectionReport CreateBlankReport()
{
	var report = new SectionReport();

	report.Sections.Add(new PageHeader { Height = 0F });
	report.Sections.Add(new Detail { Height = 0.1F });
	report.Sections.Add(new PageFooter { Height = 0F });

	return report;
}