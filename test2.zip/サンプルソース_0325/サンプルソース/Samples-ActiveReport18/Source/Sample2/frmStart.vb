﻿Imports System.IO
Imports System.Text
Imports GrapeCity.ActiveReports
Imports GrapeCity.ActiveReports.Document.Section
Imports GrapeCity.ActiveReports.SectionReportModel
Imports Newtonsoft.Json

Public Class frmStart

    ''' <summary>
    ''' ビルプリント用マスタdatarow
    ''' </summary>
    ''' <remarks></remarks>
    Private mDtbRowMstr As DataRow()

    ''' <summary>
    ''' 非表示列テータ
    ''' </summary>
    ''' <remarks></remarks>
    Private mHashControl As New Hashtable

    ''' <summary>
    ''' 非表示列テータ
    ''' </summary>
    ''' <remarks></remarks>
    Private mHashControlVisible As New Hashtable

    Private Sub frmStart_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboBox1.Items.Add("全項目出力")
        ComboBox1.Items.Add("明細項目出力")
        ComboBox1.SelectedIndex = 0

        LogHelper.SetLogTextControl(Me.TextBox1)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        mReport_set(0)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        mReport_set(1)
    End Sub

    Private Sub mReport_set(outputKbn As Integer)
        LogHelper.LogInfo("帳票出力開始")
        ' レポートのデザイナオブジェクトを作成します。
        Dim rpt As New SampleReport1

        Dim result As String = Nothing

        Dim jsonContent As String = File.ReadAllText("FRL501P15_J.json", Encoding.GetEncoding("utf-8"))

        '' 帳票JSONデータのデシリアライズ
        Dim reportRequest As ReportRequestData = JsonConvert.DeserializeObject(Of ReportRequestData)(jsonContent)


        Dim reportDatadata As String = JsonConvert.SerializeObject(reportRequest.ReportData)
        Dim reportDataset As FRL5010X = JsonConvert.DeserializeObject(Of FRL5010X)(reportDatadata)

        rpt.DataSource = reportDataset
        rpt.DataMember = "FRL5010R"

        If reportRequest.ReportInfo.UnboundField IsNot Nothing Then
            For Each tableName As String In reportRequest.ReportInfo.UnboundField
                SubSetUnboundField(rpt, reportDataset, tableName)
                SubSetUnboundData(rpt, reportDataset, tableName)
            Next
        End If

        'For Each Item As GrapeCity.ActiveReports.SectionReportModel.Section In rpt.Sections
        '    If Item.Type <> SectionType.Detail AndAlso
        '                Item.Type <> SectionType.GroupHeader AndAlso
        '                Item.Type <> SectionType.GroupFooter Then
        '        AddHandler Item.BeforePrint, AddressOf Header_BeforePrint
        '    Else
        '        AddHandler Item.BeforePrint, AddressOf Detail_BeforePrint
        '        AddHandler Item.AfterPrint, AddressOf Detail_AfterPrint
        '    End If
        'Next

        LogHelper.LogInfo("帳票作成開始")
        ' レポートを作成します。
        rpt.Run(False)
        LogHelper.LogInfo("帳票作成終了")

        If outputKbn = 0 Then
            Dim frmViewer1 As New frmViewer()
            If ComboBox1.SelectedIndex = 1 Then
                frmViewer1.PActiveReport = rpt
            End If

            frmViewer1.ActItem_xViewer.Document = rpt.Document
            frmViewer1.Show()
        Else
            LogHelper.LogInfo("帳票印刷開始")
            rpt.Document.Print(False, False, False)
            LogHelper.LogInfo("帳票印刷終了")
        End If

        LogHelper.LogInfo("帳票出力終了")
    End Sub

    ''' <summary>
    ''' ﾍｯﾀﾞｰ部のフィールドを追加
    ''' </summary>
    ''' <param name="pDstRpt">
    ''' データセット
    ''' </param>
    ''' <param name="pStrHedTbl">
    ''' データテーブル名
    ''' </param>
    ''' <remarks></remarks>
    Protected Overridable Sub SubSetUnboundField(rClsRpt As GrapeCity.ActiveReports.SectionReport, ByRef pDstRpt As FRL5010X, ByVal pStrHedTbl As String)

        Dim wDtbHeader As DataTable

        '■■ヘッダデータ設定処理
        wDtbHeader = pDstRpt.Tables(pStrHedTbl)

        For Each wDtbCol As DataColumn In wDtbHeader.Columns
            rClsRpt.Fields.Add(wDtbCol.ColumnName)
        Next

    End Sub
    ''' <summary>
    ''' ﾍｯﾀﾞｰ部のフィールドに値を設定処理を行う
    ''' </summary>
    ''' <param name="pDstRpt">
    ''' データセット
    ''' </param>
    ''' <param name="pStrHedTbl">
    ''' データテーブル名
    ''' </param>
    ''' <remarks></remarks>
    Protected Overridable Sub SubSetUnboundData(rClsRpt As GrapeCity.ActiveReports.SectionReport, ByRef pDstRpt As FRL5010X, ByVal pStrHedTbl As String)

        Dim wDtbHeader As DataTable

        '■■ヘッダデータ設定処理
        wDtbHeader = pDstRpt.Tables(pStrHedTbl)

        For Each wDtbCol As DataColumn In wDtbHeader.Columns
            rClsRpt.Fields(wDtbCol.ColumnName).Value = wDtbHeader.Rows(0)(wDtbCol.ColumnName)
        Next

    End Sub

    ''' <summary>
    ''' 非表示列テータ処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Detail_BeforePrint(ByVal sender As Object, ByVal e As System.EventArgs)

        Console.WriteLine("Detail_BeforePrint")

        Dim detail As GrapeCity.ActiveReports.SectionReportModel.Section = sender
        For Each control As ARControl In detail.Controls
            If String.IsNullOrEmpty(control.DataField) Then
                Select Case control.GetType.Name
                    Case GetType(GrapeCity.ActiveReports.SectionReportModel.TextBox).Name
                        Dim wCtrlTxtBox As GrapeCity.ActiveReports.SectionReportModel.TextBox = CType(control, GrapeCity.ActiveReports.SectionReportModel.TextBox)
                        Me.mHashControl.Add(wCtrlTxtBox.Name, wCtrlTxtBox.Text)
                    Case GetType(GrapeCity.ActiveReports.SectionReportModel.Label).Name
                        Dim wCtrlLbl As GrapeCity.ActiveReports.SectionReportModel.Label = CType(control, GrapeCity.ActiveReports.SectionReportModel.Label)
                        Me.mHashControl.Add(wCtrlLbl.Name, wCtrlLbl.Text)
                End Select
            End If
        Next
        For Each control As ARControl In detail.Controls
            If control.Visible = False Then
                mHashControlVisible.Add(control.Name, control)
                Select Case control.GetType.Name
                    Case GetType(GrapeCity.ActiveReports.SectionReportModel.TextBox).Name
                        Dim wCtrlTxtBox As GrapeCity.ActiveReports.SectionReportModel.TextBox = CType(control, GrapeCity.ActiveReports.SectionReportModel.TextBox)
                        wCtrlTxtBox.Text = " "
                        wCtrlTxtBox.Value = " "
                    Case GetType(GrapeCity.ActiveReports.SectionReportModel.Label).Name
                        Dim wCtrlLbl As GrapeCity.ActiveReports.SectionReportModel.Label = CType(control, GrapeCity.ActiveReports.SectionReportModel.Label)
                        wCtrlLbl.Text = " "
                        wCtrlLbl.Value = " "
                    Case GetType(GrapeCity.ActiveReports.SectionReportModel.SubReport).Name
                        If CType(control, GrapeCity.ActiveReports.SectionReportModel.SubReport).Report IsNot Nothing Then
                            For Each Item As GrapeCity.ActiveReports.SectionReportModel.Section In CType(control, GrapeCity.ActiveReports.SectionReportModel.SubReport).Report.Sections
                                AddHandler Item.BeforePrint, AddressOf Detail_BeforePrint
                                AddHandler Item.AfterPrint, AddressOf Detail_AfterPrint
                            Next
                        End If
                End Select
                control.Visible = True
            Else
                Select Case control.GetType.Name
                    Case GetType(GrapeCity.ActiveReports.SectionReportModel.TextBox).Name
                        Dim wCtrlTxtBox As GrapeCity.ActiveReports.SectionReportModel.TextBox = CType(control, GrapeCity.ActiveReports.SectionReportModel.TextBox)
                        If String.IsNullOrEmpty(control.DataField) Then
                            wCtrlTxtBox.Text = mHashControl(wCtrlTxtBox.Name)
                            wCtrlTxtBox.Value = mHashControl(wCtrlTxtBox.Name)
                        End If
                    Case GetType(GrapeCity.ActiveReports.SectionReportModel.Label).Name
                        Dim wCtrlLbl As GrapeCity.ActiveReports.SectionReportModel.Label = CType(control, GrapeCity.ActiveReports.SectionReportModel.Label)
                        If String.IsNullOrEmpty(control.DataField) Then
                            wCtrlLbl.Text = mHashControl(wCtrlLbl.Name)
                            wCtrlLbl.Value = mHashControl(wCtrlLbl.Name)
                        End If

                    Case GetType(GrapeCity.ActiveReports.SectionReportModel.SubReport).Name
                        If CType(control, GrapeCity.ActiveReports.SectionReportModel.SubReport).Report IsNot Nothing Then
                            For Each Item As GrapeCity.ActiveReports.SectionReportModel.Section In CType(control, GrapeCity.ActiveReports.SectionReportModel.SubReport).Report.Sections
                                AddHandler Item.BeforePrint, AddressOf Detail_BeforePrint
                                AddHandler Item.AfterPrint, AddressOf Detail_AfterPrint
                            Next
                        End If
                End Select
            End If
        Next
        Me.mHashControl.Clear()
    End Sub

    ''' <summary>
    ''' 非表示列テータAfterPrint処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Detail_AfterPrint(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim wEnumerator As System.Collections.IDictionaryEnumerator = mHashControlVisible.GetEnumerator()
        While (wEnumerator.MoveNext)
            Select Case mHashControlVisible.Item(wEnumerator.Key.ToString).GetType.Name
                Case GetType(GrapeCity.ActiveReports.SectionReportModel.TextBox).Name
                    Dim wCtrlTxtBox As GrapeCity.ActiveReports.SectionReportModel.TextBox = CType(mHashControlVisible.Item(wEnumerator.Key.ToString), GrapeCity.ActiveReports.SectionReportModel.TextBox)
                    wCtrlTxtBox.Visible = False
                Case GetType(GrapeCity.ActiveReports.SectionReportModel.Label).Name
                    Dim wCtrlLbl As GrapeCity.ActiveReports.SectionReportModel.Label = CType(mHashControlVisible.Item(wEnumerator.Key.ToString), GrapeCity.ActiveReports.SectionReportModel.Label)
                    wCtrlLbl.Visible = False
            End Select
        End While
        mHashControlVisible.Clear()
    End Sub


    ''' <summary>
    ''' CSV出力の非表示項目設定処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Header_BeforePrint(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim detail As GrapeCity.ActiveReports.SectionReportModel.Section = sender
        For Each control As ARControl In detail.Controls
            control.Visible = False
        Next
    End Sub


End Class