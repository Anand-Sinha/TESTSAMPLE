﻿''' <summary>
''' 帳票出力WebAPIリクエストデータクラス
''' </summary>
Public Class ReportRequestData

    ''' <summary>
    ''' 帳票出力情報
    ''' </summary>
    Private _reportInfo As ReportInfo
    Public Property ReportInfo() As ReportInfo
        Get
            Return _reportInfo
        End Get
        Set(ByVal value As ReportInfo)
            _reportInfo = value
        End Set
    End Property

    ''' <summary>
    ''' 帳票データ
    ''' </summary>
    Private _reportData As Object
    Public Property ReportData() As Object
        Get
            Return _reportData
        End Get
        Set(ByVal value As Object)
            _reportData = value
        End Set
    End Property

End Class

''' <summary>
''' 帳票出力条件クラス
''' </summary>
Public Class ReportInfo

    ''' <summary>
    ''' 帳票出力モード
    ''' </summary>
    Private _funcMode As Integer
    Public Property FuncMode() As Integer
        Get
            Return _funcMode
        End Get
        Set(ByVal value As Integer)
            _funcMode = value
        End Set
    End Property

    ''' <summary>
    ''' 帳票処理クラス
    ''' </summary>
    Private _reportLogicClass As String
    Public Property ReportLogicClass() As String
        Get
            Return _reportLogicClass
        End Get
        Set(ByVal value As String)
            _reportLogicClass = value
        End Set
    End Property

    ''' <summary>
    ''' メイン帳票クラス
    ''' </summary>
    Private _mainReportClass As String
    Public Property MainReportClass() As String
        Get
            Return _mainReportClass
        End Get
        Set(ByVal value As String)
            _mainReportClass = value
        End Set
    End Property

    ''' <summary>
    ''' データセットクラス
    ''' </summary>
    Private _datasetClass As String
    Public Property DatasetClass() As String
        Get
            Return _datasetClass
        End Get
        Set(ByVal value As String)
            _datasetClass = value
        End Set
    End Property

    ''' <summary>
    ''' メイン帳票のデータメンバ名
    ''' </summary>
    Private _reportDataMember As String
    Public Property ReportDataMember() As String
        Get
            Return _reportDataMember
        End Get
        Set(ByVal value As String)
            _reportDataMember = value
        End Set
    End Property

    ''' <summary>
    ''' 言語ID
    ''' </summary>
    ''' <remarks>現行処理ではログインクラークの言語を使用？</remarks>
    Private _langID As String
    Public Property LangID() As String
        Get
            Return _langID
        End Get
        Set(ByVal value As String)
            _langID = value
        End Set
    End Property

    ''' <summary>
    ''' 帳票メイン処理パラメータ
    ''' </summary>
    Private _pStrItems As String()
    Public Property PStrItems() As String()
        Get
            Return _pStrItems
        End Get
        Set(ByVal value As String())
            _pStrItems = value
        End Set
    End Property

    ''' <summary>
    ''' アンバウンドフィールドのデータテーブル名リスト
    ''' </summary>
    Private _unboundField As String()
    Public Property UnboundField() As String()
        Get
            Return _unboundField
        End Get
        Set(ByVal value As String())
            _unboundField = value
        End Set
    End Property

    ''' <summary>
    ''' 印刷先プリンタ名
    ''' </summary>
    Private _printeName As String
    Public Property PrinteName() As String
        Get
            Return _printeName
        End Get
        Set(ByVal value As String)
            _printeName = value
        End Set
    End Property

    ''' <summary>
    ''' 売上帳票パラメータ
    ''' </summary>
    ''' <returns></returns>
    Private _statInfo As StatInfo
    Public Property StatInfo() As StatInfo
        Get
            Return _statInfo
        End Get
        Set(ByVal value As StatInfo)
            _statInfo = value
        End Set
    End Property

    ''' <summary>
    ''' 帳票出力情報セット
    ''' </summary>
    Private _mUdtRpt As MUdtRpt
    Public Property MUdtRpt() As MUdtRpt
        Get
            Return _mUdtRpt
        End Get
        Set(ByVal value As MUdtRpt)
            _mUdtRpt = value
        End Set
    End Property

    ''' <summary>
    ''' 帳票権限なしフラグ
    ''' </summary>
    Private _noneAuthority As Integer
    Public Property NoneAuthority() As Integer
        Get
            Return _noneAuthority
        End Get
        Set(ByVal value As Integer)
            _noneAuthority = value
        End Set
    End Property

End Class

Public Class MUdtRpt

    ''' <summary>
    ''' 帳票出力モード
    ''' </summary>
    ''' <remarks>現新比較用。FuncModeに転記</remarks>
    ''' <returns></returns>
    Private _rptProcess As String
    Public WriteOnly Property RptProcess() As String
        Set(ByVal value As String)
            _rptProcess = value
        End Set
    End Property

    ''' <summary>
    ''' 帳票ファイル名
    ''' </summary>
    Private _name As String
    Public WriteOnly Property Name() As String
        Set(ByVal value As String)
            _name = value
        End Set
    End Property

    ''' <summary>
    ''' エクスポート形式
    ''' </summary>
    Private _expType As Integer
    Public WriteOnly Property ExpType() As Integer
        Set(ByVal value As Integer)
            _expType = value
        End Set
    End Property

    ''' <summary>
    ''' エクスポートファイル名
    ''' </summary>
    ''' <returns></returns>
    Private _expFileNM As String
    Public WriteOnly Property ExpFileNM() As String
        Set(ByVal value As String)
            _expFileNM = value
        End Set
    End Property

    ''' <summary>
    ''' エクスポートNo
    ''' </summary>
    Private _expFileNo As String
    Public WriteOnly Property ExpFileNo() As String
        Set(ByVal value As String)
            _expFileNo = value
        End Set
    End Property

    ''' <summary>
    ''' エクスポートパス
    ''' </summary>
    Private _expPath As String
    Public WriteOnly Property ExpPath() As String
        Set(ByVal value As String)
            _expPath = value
        End Set
    End Property

    ''' <summary>
    ''' 棟コード
    ''' </summary>
    Private _towercd As String
    Public WriteOnly Property Towercd() As String
        Set(ByVal value As String)
            _towercd = value
        End Set
    End Property

    ''' <summary>
    ''' タイトル
    ''' </summary>
    Private _title As String
    Public WriteOnly Property Title() As String
        Set(ByVal value As String)
            _title = value
        End Set
    End Property

End Class

Public Class StatInfo

    ''' <summary>
    ''' オプション適用コード
    ''' </summary>
    Private _myOptionTekiyo As String
    Public Property MyOptionTekiyo() As String
        Get
            Return _myOptionTekiyo
        End Get
        Set(ByVal value As String)
            _myOptionTekiyo = value
        End Set
    End Property

    ''' <summary>
    ''' 
    ''' </summary>
    Private _strHotelNm As String
    Public Property StrHotelNm() As String
        Get
            Return _strHotelNm
        End Get
        Set(ByVal value As String)
            _strHotelNm = value
        End Set
    End Property

    ''' <summary>
    ''' 
    ''' </summary>
    Private _enmLogInKbn As Integer
    Public Property EnmLogInKbn() As Integer
        Get
            Return _enmLogInKbn
        End Get
        Set(ByVal value As Integer)
            _enmLogInKbn = value
        End Set
    End Property

End Class
