﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Public Class SampleReport1
    Inherits GrapeCity.ActiveReports.SectionReport

    'ActiveReport がコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
        End If
        MyBase.Dispose(disposing)
    End Sub

    'メモ: 以下のプロシージャは ActiveReport デザイナで必要です。
    'ActiveReport デザイナを使用して変更できます。
    'コード エディタを使って変更しないでください。
    Private WithEvents Detail As GrapeCity.ActiveReports.SectionReportModel.Detail
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(SampleReport1))
        Me.PageHeader = New GrapeCity.ActiveReports.SectionReportModel.PageHeader
        Me.MSTRDATA3 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA2 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA1 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA4 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA5 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA6 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA7 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA8 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl001 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.CGST = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl002 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.ROOMNO = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl003 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.PSN = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl004 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.CIDATE = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl005 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.CODATE = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl006 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.TextBox17 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl007 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl008 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl009 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl010 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl011 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.Line2 = New GrapeCity.ActiveReports.SectionReportModel.Line
        Me.MSTRDATA20 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA21 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA22 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA23 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA24 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.Detail = New GrapeCity.ActiveReports.SectionReportModel.Detail
        Me.MMDD = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.EXPL = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.RMNO = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.CHRG = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.CRDT = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.CHIT = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.NOTAXKBN = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MARK = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.SEPMARK = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.PageFooter = New GrapeCity.ActiveReports.SectionReportModel.PageFooter
        Me.HdLbl012 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.CHGSUM = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.CRGSUM = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.Line1 = New GrapeCity.ActiveReports.SectionReportModel.Line
        Me.ReportHeader1 = New GrapeCity.ActiveReports.SectionReportModel.ReportHeader
        Me.ReportFooter1 = New GrapeCity.ActiveReports.SectionReportModel.ReportFooter
        Me.HdLbl013 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.TextBox33 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl014 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl015 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.TextBox36 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.TextBox37 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl028 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl128 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA9 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl016 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA10 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl017 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl018 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.CNM = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.ADDR = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.SEC = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl101 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.PRNTNM = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl021 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl022 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.ISSUNO = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA11 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.Line4 = New GrapeCity.ActiveReports.SectionReportModel.Line
        Me.HdLbl023 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl200 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.RECEIPTNM = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl024 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.RECEIPTAMT = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl025 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.RECEIPTMEMO = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl026 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA13 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA12 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl027 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.RECEIPTDATE = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.BLNO = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.Shape1 = New GrapeCity.ActiveReports.SectionReportModel.Shape
        Me.TextBox1 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.TextBox3 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.PAYDATA = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.Line5 = New GrapeCity.ActiveReports.SectionReportModel.Line
        Me.Line6 = New GrapeCity.ActiveReports.SectionReportModel.Line
        Me.Line7 = New GrapeCity.ActiveReports.SectionReportModel.Line
        Me.Line8 = New GrapeCity.ActiveReports.SectionReportModel.Line
        Me.Line9 = New GrapeCity.ActiveReports.SectionReportModel.Line
        Me.HdLbl034 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl033 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.PMINUS = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.EXPPOINT = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl035 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.PMINUS_E = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl035_E = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.LNGCD = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl033_E = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.EXPPOINT_E = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.TITLESUMAMT1 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.TITLESUMAMT2 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.SUMAMT1 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.SUMAMT2 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MARKSETUMEI = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl066 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl066_1 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.PRTTAX1 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.PRTTAX2 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl028_2 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.HdLbl028_1 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.TITLETAXNOT = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.TITLEOTHER = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.SUMOTHERAMT = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.SUMTAXNOTAMT = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA25 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA27 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA28 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA29 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.MSTRDATA26 = New GrapeCity.ActiveReports.SectionReportModel.TextBox
        Me.GroupHeader1 = New GrapeCity.ActiveReports.SectionReportModel.GroupHeader
        Me.GroupFooter1 = New GrapeCity.ActiveReports.SectionReportModel.GroupFooter
        CType(Me.MSTRDATA3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl001, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CGST, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl002, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ROOMNO, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl003, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PSN, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl004, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CIDATE, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl005, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CODATE, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl006, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl007, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl008, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl009, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl010, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl011, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MMDD, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EXPL, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RMNO, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CHRG, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CRDT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CHIT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NOTAXKBN, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MARK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SEPMARK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl012, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CHGSUM, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CRGSUM, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl013, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl014, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl015, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox36, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox37, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl028, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl128, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl016, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl017, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl018, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CNM, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ADDR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SEC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl101, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PRNTNM, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl021, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl022, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ISSUNO, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl023, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl200, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RECEIPTNM, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl024, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RECEIPTAMT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl025, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RECEIPTMEMO, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl026, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl027, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RECEIPTDATE, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BLNO, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PAYDATA, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl034, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl033, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PMINUS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EXPPOINT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl035, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PMINUS_E, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl035_E, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LNGCD, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl033_E, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EXPPOINT_E, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TITLESUMAMT1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TITLESUMAMT2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SUMAMT1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SUMAMT2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MARKSETUMEI, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl066, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl066_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PRTTAX1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PRTTAX2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl028_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HdLbl028_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TITLETAXNOT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TITLEOTHER, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SUMOTHERAMT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SUMTAXNOTAMT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA27, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA28, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSTRDATA26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'PageHeader
        '
        Me.PageHeader.Controls.AddRange(New GrapeCity.ActiveReports.SectionReportModel.ARControl() {Me.MSTRDATA3, Me.MSTRDATA2, Me.MSTRDATA1, Me.MSTRDATA4, Me.MSTRDATA5, Me.MSTRDATA6, Me.MSTRDATA7, Me.MSTRDATA8, Me.HdLbl001, Me.CGST, Me.HdLbl002, Me.ROOMNO, Me.HdLbl003, Me.PSN, Me.HdLbl004, Me.CIDATE, Me.HdLbl005, Me.CODATE, Me.HdLbl006, Me.TextBox17, Me.HdLbl007, Me.HdLbl008, Me.HdLbl009, Me.HdLbl010, Me.HdLbl011, Me.Line2, Me.MSTRDATA20, Me.MSTRDATA21, Me.MSTRDATA22, Me.MSTRDATA23, Me.MSTRDATA24})
        Me.PageHeader.Height = 2.331995!
        Me.PageHeader.Name = "PageHeader"
        '
        'MSTRDATA3
        '
        Me.MSTRDATA3.CanGrow = False
        Me.MSTRDATA3.DataField = "MSTRDATA3"
        Me.MSTRDATA3.Height = 0.1771654!
        Me.MSTRDATA3.Left = 4.067717!
        Me.MSTRDATA3.MultiLine = False
        Me.MSTRDATA3.Name = "MSTRDATA3"
        Me.MSTRDATA3.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap; ddo-char-set: 1"
        Me.MSTRDATA3.Text = "NECホテル 東京"
        Me.MSTRDATA3.Top = 0.668898!
        Me.MSTRDATA3.Width = 3.330709!
        '
        'MSTRDATA2
        '
        Me.MSTRDATA2.CanGrow = False
        Me.MSTRDATA2.DataField = "MSTRDATA2"
        Me.MSTRDATA2.Height = 0.1771654!
        Me.MSTRDATA2.Left = 4.067717!
        Me.MSTRDATA2.MultiLine = False
        Me.MSTRDATA2.Name = "MSTRDATA2"
        Me.MSTRDATA2.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap; ddo-char-set: 1"
        Me.MSTRDATA2.Text = "NECホテル 東京"
        Me.MSTRDATA2.Top = 0.4688977!
        Me.MSTRDATA2.Width = 3.330709!
        '
        'MSTRDATA1
        '
        Me.MSTRDATA1.CanGrow = False
        Me.MSTRDATA1.DataField = "MSTRDATA1"
        Me.MSTRDATA1.Height = 0.1979166!
        Me.MSTRDATA1.Left = 0.5937008!
        Me.MSTRDATA1.MultiLine = False
        Me.MSTRDATA1.Name = "MSTRDATA1"
        Me.MSTRDATA1.Style = "font-family: ＭＳ 明朝; font-size: 12pt; font-weight: bold; text-align: left; white-s" &
            "pace: nowrap"
        Me.MSTRDATA1.Text = "マスタ文言"
        Me.MSTRDATA1.Top = 0.4791339!
        Me.MSTRDATA1.Width = 2.685827!
        '
        'MSTRDATA4
        '
        Me.MSTRDATA4.CanGrow = False
        Me.MSTRDATA4.DataField = "MSTRDATA4"
        Me.MSTRDATA4.Height = 0.1771654!
        Me.MSTRDATA4.Left = 4.067717!
        Me.MSTRDATA4.MultiLine = False
        Me.MSTRDATA4.Name = "MSTRDATA4"
        Me.MSTRDATA4.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap; ddo-char-set: 1"
        Me.MSTRDATA4.Text = "NECホテル 東京"
        Me.MSTRDATA4.Top = 0.8791342!
        Me.MSTRDATA4.Width = 3.330709!
        '
        'MSTRDATA5
        '
        Me.MSTRDATA5.CanGrow = False
        Me.MSTRDATA5.DataField = "MSTRDATA5"
        Me.MSTRDATA5.Height = 0.1771654!
        Me.MSTRDATA5.Left = 4.067717!
        Me.MSTRDATA5.MultiLine = False
        Me.MSTRDATA5.Name = "MSTRDATA5"
        Me.MSTRDATA5.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap; ddo-char-set: 1"
        Me.MSTRDATA5.Text = "NECホテル 東京"
        Me.MSTRDATA5.Top = 1.08937!
        Me.MSTRDATA5.Width = 3.330709!
        '
        'MSTRDATA6
        '
        Me.MSTRDATA6.CanGrow = False
        Me.MSTRDATA6.DataField = "MSTRDATA6"
        Me.MSTRDATA6.Height = 0.1771654!
        Me.MSTRDATA6.Left = 4.067717!
        Me.MSTRDATA6.MultiLine = False
        Me.MSTRDATA6.Name = "MSTRDATA6"
        Me.MSTRDATA6.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap; ddo-char-set: 1"
        Me.MSTRDATA6.Text = "NECホテル 東京"
        Me.MSTRDATA6.Top = 1.299606!
        Me.MSTRDATA6.Width = 3.330709!
        '
        'MSTRDATA7
        '
        Me.MSTRDATA7.CanGrow = False
        Me.MSTRDATA7.DataField = "MSTRDATA7"
        Me.MSTRDATA7.Height = 0.1771654!
        Me.MSTRDATA7.Left = 4.067717!
        Me.MSTRDATA7.MultiLine = False
        Me.MSTRDATA7.Name = "MSTRDATA7"
        Me.MSTRDATA7.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap; ddo-char-set: 1"
        Me.MSTRDATA7.Text = "NECホテル 東京"
        Me.MSTRDATA7.Top = 1.520079!
        Me.MSTRDATA7.Width = 3.330709!
        '
        'MSTRDATA8
        '
        Me.MSTRDATA8.CanGrow = False
        Me.MSTRDATA8.DataField = "MSTRDATA8"
        Me.MSTRDATA8.Height = 0.1771654!
        Me.MSTRDATA8.Left = 4.067717!
        Me.MSTRDATA8.MultiLine = False
        Me.MSTRDATA8.Name = "MSTRDATA8"
        Me.MSTRDATA8.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap; ddo-char-set: 1"
        Me.MSTRDATA8.Text = "NECホテル 東京"
        Me.MSTRDATA8.Top = 1.736614!
        Me.MSTRDATA8.Width = 3.330709!
        '
        'HdLbl001
        '
        Me.HdLbl001.CanGrow = False
        Me.HdLbl001.DataField = "HdLbl001"
        Me.HdLbl001.Height = 0.1692913!
        Me.HdLbl001.Left = 0.0!
        Me.HdLbl001.MultiLine = False
        Me.HdLbl001.Name = "HdLbl001"
        Me.HdLbl001.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl001.Text = "お名前"
        Me.HdLbl001.Top = 0.899605!
        Me.HdLbl001.Width = 0.8244097!
        '
        'CGST
        '
        Me.CGST.CanGrow = False
        Me.CGST.DataField = "CGST"
        Me.CGST.Height = 0.507874!
        Me.CGST.Left = 0.8771654!
        Me.CGST.Name = "CGST"
        Me.CGST.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: inherit"
        Me.CGST.Text = "わ1わわわわわわわわ0)わわわわわわわわわ1)わわわわわわわわわ2)わわわわわわわわわ3)わわわわわわわわわ4)わわわわわわわわわ5)わわA"
        Me.CGST.Top = 0.8996063!
        Me.CGST.Width = 4.031496!
        '
        'HdLbl002
        '
        Me.HdLbl002.CanGrow = False
        Me.HdLbl002.DataField = "HdLbl002"
        Me.HdLbl002.Height = 0.1692913!
        Me.HdLbl002.Left = 0.0!
        Me.HdLbl002.MultiLine = False
        Me.HdLbl002.Name = "HdLbl002"
        Me.HdLbl002.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl002.Text = "お部屋番号"
        Me.HdLbl002.Top = 1.520079!
        Me.HdLbl002.Width = 0.8244097!
        '
        'ROOMNO
        '
        Me.ROOMNO.CanGrow = False
        Me.ROOMNO.DataField = "ROOMNO"
        Me.ROOMNO.Height = 0.1692913!
        Me.ROOMNO.Left = 1.126378!
        Me.ROOMNO.MultiLine = False
        Me.ROOMNO.Name = "ROOMNO"
        Me.ROOMNO.Style = "font-family: ＭＳ 明朝; font-size: 11pt; text-align: right; white-space: nowrap"
        Me.ROOMNO.Text = "99999"
        Me.ROOMNO.Top = 1.520079!
        Me.ROOMNO.Width = 0.5996062!
        '
        'HdLbl003
        '
        Me.HdLbl003.CanGrow = False
        Me.HdLbl003.DataField = "HdLbl003"
        Me.HdLbl003.Height = 0.1692913!
        Me.HdLbl003.Left = 2.364567!
        Me.HdLbl003.MultiLine = False
        Me.HdLbl003.Name = "HdLbl003"
        Me.HdLbl003.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl003.Text = "ご人数"
        Me.HdLbl003.Top = 1.520079!
        Me.HdLbl003.Width = 0.7409456!
        '
        'PSN
        '
        Me.PSN.CanGrow = False
        Me.PSN.DataField = "PSN"
        Me.PSN.Height = 0.1692913!
        Me.PSN.Left = 3.366537!
        Me.PSN.MultiLine = False
        Me.PSN.Name = "PSN"
        Me.PSN.Style = "font-family: ＭＳ 明朝; font-size: 11pt; text-align: right; white-space: nowrap"
        Me.PSN.Text = "999"
        Me.PSN.Top = 1.52008!
        Me.PSN.Width = 0.6023607!
        '
        'HdLbl004
        '
        Me.HdLbl004.CanGrow = False
        Me.HdLbl004.DataField = "HdLbl004"
        Me.HdLbl004.Height = 0.1692913!
        Me.HdLbl004.Left = 0.0!
        Me.HdLbl004.MultiLine = False
        Me.HdLbl004.Name = "HdLbl004"
        Me.HdLbl004.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl004.Text = "ご到着"
        Me.HdLbl004.Top = 1.791733!
        Me.HdLbl004.Width = 0.8244097!
        '
        'CIDATE
        '
        Me.CIDATE.CanGrow = False
        Me.CIDATE.DataField = "RCIDATE"
        Me.CIDATE.Height = 0.1692913!
        Me.CIDATE.Left = 0.9181104!
        Me.CIDATE.MultiLine = False
        Me.CIDATE.Name = "CIDATE"
        Me.CIDATE.Style = "font-family: ＭＳ 明朝; font-size: 11pt; text-align: right; white-space: nowrap"
        Me.CIDATE.Text = "9999/99/99"
        Me.CIDATE.Top = 1.791733!
        Me.CIDATE.Width = 0.8078739!
        '
        'HdLbl005
        '
        Me.HdLbl005.CanGrow = False
        Me.HdLbl005.DataField = "HdLbl005"
        Me.HdLbl005.Height = 0.1692913!
        Me.HdLbl005.Left = 2.364567!
        Me.HdLbl005.MultiLine = False
        Me.HdLbl005.Name = "HdLbl005"
        Me.HdLbl005.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl005.Text = "ご出発"
        Me.HdLbl005.Top = 1.791733!
        Me.HdLbl005.Width = 0.7409456!
        '
        'CODATE
        '
        Me.CODATE.CanGrow = False
        Me.CODATE.DataField = "CODATE"
        Me.CODATE.Height = 0.1692913!
        Me.CODATE.Left = 3.158269!
        Me.CODATE.MultiLine = False
        Me.CODATE.Name = "CODATE"
        Me.CODATE.Style = "font-family: ＭＳ 明朝; font-size: 11pt; text-align: right; white-space: nowrap"
        Me.CODATE.Text = "9999/99/99"
        Me.CODATE.Top = 1.791733!
        Me.CODATE.Width = 0.8106288!
        '
        'HdLbl006
        '
        Me.HdLbl006.CanGrow = False
        Me.HdLbl006.DataField = "HdLbl006"
        Me.HdLbl006.Height = 0.1692913!
        Me.HdLbl006.Left = 0.0!
        Me.HdLbl006.MultiLine = False
        Me.HdLbl006.Name = "HdLbl006"
        Me.HdLbl006.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl006.Tag = ""
        Me.HdLbl006.Text = "日付"
        Me.HdLbl006.Top = 2.140551!
        Me.HdLbl006.Width = 0.5314961!
        '
        'TextBox17
        '
        Me.TextBox17.CanGrow = False
        Me.TextBox17.Height = 0.1692913!
        Me.TextBox17.Left = 7.195276!
        Me.TextBox17.MultiLine = False
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Style = "font-family: ＭＳ 明朝; font-size: 11pt; text-align: right; white-space: nowrap"
        Me.TextBox17.SummaryRunning = GrapeCity.ActiveReports.SectionReportModel.SummaryRunning.All
        Me.TextBox17.SummaryType = GrapeCity.ActiveReports.SectionReportModel.SummaryType.PageCount
        Me.TextBox17.Text = "999"
        Me.TextBox17.Top = 1.990945!
        Me.TextBox17.Width = 0.3244219!
        '
        'HdLbl007
        '
        Me.HdLbl007.CanGrow = False
        Me.HdLbl007.DataField = "HdLbl007"
        Me.HdLbl007.Height = 0.1692913!
        Me.HdLbl007.Left = 0.5905512!
        Me.HdLbl007.MultiLine = False
        Me.HdLbl007.Name = "HdLbl007"
        Me.HdLbl007.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl007.Tag = ""
        Me.HdLbl007.Text = "科目名"
        Me.HdLbl007.Top = 2.140551!
        Me.HdLbl007.Width = 1.011811!
        '
        'HdLbl008
        '
        Me.HdLbl008.CanGrow = False
        Me.HdLbl008.DataField = "HdLbl008"
        Me.HdLbl008.Height = 0.1692913!
        Me.HdLbl008.Left = 2.443307!
        Me.HdLbl008.MultiLine = False
        Me.HdLbl008.Name = "HdLbl008"
        Me.HdLbl008.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl008.Tag = ""
        Me.HdLbl008.Text = "部屋番号"
        Me.HdLbl008.Top = 2.140551!
        Me.HdLbl008.Width = 0.8244097!
        '
        'HdLbl009
        '
        Me.HdLbl009.CanGrow = False
        Me.HdLbl009.DataField = "HdLbl009"
        Me.HdLbl009.Height = 0.1692913!
        Me.HdLbl009.Left = 3.491338!
        Me.HdLbl009.MultiLine = False
        Me.HdLbl009.Name = "HdLbl009"
        Me.HdLbl009.Style = "font-family: ＭＳ 明朝; font-size: 11pt; text-align: right; white-space: nowrap"
        Me.HdLbl009.Tag = ""
        Me.HdLbl009.Text = "料金"
        Me.HdLbl009.Top = 2.140551!
        Me.HdLbl009.Width = 0.9598423!
        '
        'HdLbl010
        '
        Me.HdLbl010.CanGrow = False
        Me.HdLbl010.DataField = "HdLbl010"
        Me.HdLbl010.Height = 0.1692913!
        Me.HdLbl010.Left = 4.559055!
        Me.HdLbl010.MultiLine = False
        Me.HdLbl010.Name = "HdLbl010"
        Me.HdLbl010.Style = "font-family: ＭＳ 明朝; font-size: 11pt; text-align: right; white-space: nowrap"
        Me.HdLbl010.Tag = ""
        Me.HdLbl010.Text = "お支払う等"
        Me.HdLbl010.Top = 2.140551!
        Me.HdLbl010.Width = 1.105512!
        '
        'HdLbl011
        '
        Me.HdLbl011.CanGrow = False
        Me.HdLbl011.DataField = "HdLbl011"
        Me.HdLbl011.Height = 0.1692913!
        Me.HdLbl011.Left = 6.019685!
        Me.HdLbl011.MultiLine = False
        Me.HdLbl011.Name = "HdLbl011"
        Me.HdLbl011.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl011.Tag = ""
        Me.HdLbl011.Text = "備考"
        Me.HdLbl011.Top = 2.141732!
        Me.HdLbl011.Width = 1.084646!
        '
        'Line2
        '
        Me.Line2.Height = 0.0!
        Me.Line2.Left = 0.0!
        Me.Line2.LineWeight = 1.0!
        Me.Line2.Name = "Line2"
        Me.Line2.Top = 2.308268!
        Me.Line2.Width = 7.574804!
        Me.Line2.X1 = 0.0!
        Me.Line2.X2 = 7.574804!
        Me.Line2.Y1 = 2.308268!
        Me.Line2.Y2 = 2.308268!
        '
        'MSTRDATA20
        '
        Me.MSTRDATA20.CanGrow = False
        Me.MSTRDATA20.DataField = "MSTRDATA20"
        Me.MSTRDATA20.Height = 0.1771654!
        Me.MSTRDATA20.Left = 0.5937008!
        Me.MSTRDATA20.MultiLine = False
        Me.MSTRDATA20.Name = "MSTRDATA20"
        Me.MSTRDATA20.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap; ddo-char-set: 1"
        Me.MSTRDATA20.Text = "T123456789012"
        Me.MSTRDATA20.Top = 0.0937008!
        Me.MSTRDATA20.Width = 3.330709!
        '
        'MSTRDATA21
        '
        Me.MSTRDATA21.CanGrow = False
        Me.MSTRDATA21.DataField = "MSTRDATA21"
        Me.MSTRDATA21.Height = 0.1771654!
        Me.MSTRDATA21.Left = 0.5937008!
        Me.MSTRDATA21.MultiLine = False
        Me.MSTRDATA21.Name = "MSTRDATA21"
        Me.MSTRDATA21.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap; ddo-char-set: 1"
        Me.MSTRDATA21.Text = "T123456789012"
        Me.MSTRDATA21.Top = 0.3019685!
        Me.MSTRDATA21.Width = 3.330709!
        '
        'MSTRDATA22
        '
        Me.MSTRDATA22.CanGrow = False
        Me.MSTRDATA22.DataField = "MSTRDATA22"
        Me.MSTRDATA22.Height = 0.1771654!
        Me.MSTRDATA22.Left = 4.067718!
        Me.MSTRDATA22.MultiLine = False
        Me.MSTRDATA22.Name = "MSTRDATA22"
        Me.MSTRDATA22.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap; ddo-char-set: 1"
        Me.MSTRDATA22.Text = "T123456789012"
        Me.MSTRDATA22.Top = 0.0937008!
        Me.MSTRDATA22.Width = 3.330709!
        '
        'MSTRDATA23
        '
        Me.MSTRDATA23.CanGrow = False
        Me.MSTRDATA23.DataField = "MSTRDATA23"
        Me.MSTRDATA23.Height = 0.1771654!
        Me.MSTRDATA23.Left = 4.067718!
        Me.MSTRDATA23.MultiLine = False
        Me.MSTRDATA23.Name = "MSTRDATA23"
        Me.MSTRDATA23.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap; ddo-char-set: 1"
        Me.MSTRDATA23.Text = "T123456789012"
        Me.MSTRDATA23.Top = 0.2708662!
        Me.MSTRDATA23.Width = 3.330709!
        '
        'MSTRDATA24
        '
        Me.MSTRDATA24.CanGrow = False
        Me.MSTRDATA24.DataField = "MSTRDATA24"
        Me.MSTRDATA24.Height = 0.1771654!
        Me.MSTRDATA24.Left = 4.067717!
        Me.MSTRDATA24.MultiLine = False
        Me.MSTRDATA24.Name = "MSTRDATA24"
        Me.MSTRDATA24.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap; ddo-char-set: 1"
        Me.MSTRDATA24.Text = "T123456789012"
        Me.MSTRDATA24.Top = 1.934252!
        Me.MSTRDATA24.Width = 3.330709!
        '
        'Detail
        '
        Me.Detail.ColumnSpacing = 0.0!
        Me.Detail.Controls.AddRange(New GrapeCity.ActiveReports.SectionReportModel.ARControl() {Me.MMDD, Me.EXPL, Me.RMNO, Me.CHRG, Me.CRDT, Me.CHIT, Me.NOTAXKBN, Me.MARK, Me.SEPMARK})
        Me.Detail.Height = 0.1968504!
        Me.Detail.Name = "Detail"
        '
        'MMDD
        '
        Me.MMDD.CanGrow = False
        Me.MMDD.DataField = "MMDD"
        Me.MMDD.Height = 0.15625!
        Me.MMDD.Left = 0.0!
        Me.MMDD.MultiLine = False
        Me.MMDD.Name = "MMDD"
        Me.MMDD.Style = "font-family: ＭＳ 明朝; font-size: 11pt; font-weight: normal; text-align: left; white" &
            "-space: nowrap"
        Me.MMDD.Text = "9999/99/99"
        Me.MMDD.Top = 0.01968504!
        Me.MMDD.Width = 0.5732284!
        '
        'EXPL
        '
        Me.EXPL.CanGrow = False
        Me.EXPL.DataField = "EXPL"
        Me.EXPL.Height = 0.15625!
        Me.EXPL.Left = 0.5905512!
        Me.EXPL.MultiLine = False
        Me.EXPL.Name = "EXPL"
        Me.EXPL.Style = "font-family: ＭＳ 明朝; font-size: 11pt; font-weight: normal; text-align: left; white" &
            "-space: nowrap"
        Me.EXPL.Text = "わわわわわわわわわ0)わわ"
        Me.EXPL.Top = 0.01968504!
        Me.EXPL.Width = 1.852756!
        '
        'RMNO
        '
        Me.RMNO.CanGrow = False
        Me.RMNO.DataField = "RMNO"
        Me.RMNO.Height = 0.15625!
        Me.RMNO.Left = 2.443306!
        Me.RMNO.MultiLine = False
        Me.RMNO.Name = "RMNO"
        Me.RMNO.Style = "font-family: ＭＳ 明朝; font-size: 11pt; font-weight: normal; text-align: left; white" &
            "-space: nowrap"
        Me.RMNO.Text = "0123456789"
        Me.RMNO.Top = 0.01968504!
        Me.RMNO.Width = 0.8244097!
        '
        'CHRG
        '
        Me.CHRG.CanGrow = False
        Me.CHRG.DataField = "CHRG"
        Me.CHRG.Height = 0.15625!
        Me.CHRG.Left = 3.295276!
        Me.CHRG.MultiLine = False
        Me.CHRG.Name = "CHRG"
        Me.CHRG.OutputFormat = resources.GetString("CHRG.OutputFormat")
        Me.CHRG.Style = "font-family: ＭＳ 明朝; font-size: 11pt; font-weight: normal; text-align: right; whit" &
            "e-space: nowrap"
        Me.CHRG.Text = "999,999,999,999"
        Me.CHRG.Top = 0.01968504!
        Me.CHRG.Width = 1.153543!
        '
        'CRDT
        '
        Me.CRDT.CanGrow = False
        Me.CRDT.DataField = "CRDT"
        Me.CRDT.Height = 0.15625!
        Me.CRDT.Left = 4.516536!
        Me.CRDT.MultiLine = False
        Me.CRDT.Name = "CRDT"
        Me.CRDT.OutputFormat = resources.GetString("CRDT.OutputFormat")
        Me.CRDT.Style = "font-family: ＭＳ 明朝; font-size: 11pt; font-weight: normal; text-align: right; whit" &
            "e-space: nowrap"
        Me.CRDT.Text = "999,999,999,999"
        Me.CRDT.Top = 0.01968504!
        Me.CRDT.Width = 1.145669!
        '
        'CHIT
        '
        Me.CHIT.CanGrow = False
        Me.CHIT.DataField = "CHIT"
        Me.CHIT.Height = 0.15625!
        Me.CHIT.Left = 6.019685!
        Me.CHIT.MultiLine = False
        Me.CHIT.Name = "CHIT"
        Me.CHIT.Style = "font-family: ＭＳ 明朝; font-size: 11pt; font-weight: normal; text-align: left; white" &
            "-space: nowrap"
        Me.CHIT.Text = "わわわわわわわわわ"
        Me.CHIT.Top = 0.01968504!
        Me.CHIT.Width = 1.622835!
        '
        'NOTAXKBN
        '
        Me.NOTAXKBN.CanGrow = False
        Me.NOTAXKBN.DataField = "NOTAXKBN"
        Me.NOTAXKBN.Height = 0.15625!
        Me.NOTAXKBN.Left = 5.728347!
        Me.NOTAXKBN.MultiLine = False
        Me.NOTAXKBN.Name = "NOTAXKBN"
        Me.NOTAXKBN.Style = "font-family: ＭＳ 明朝; font-size: 11pt; font-weight: normal; text-align: left; white" &
            "-space: nowrap"
        Me.NOTAXKBN.Text = "9"
        Me.NOTAXKBN.Top = 0.01968504!
        Me.NOTAXKBN.Width = 0.1161429!
        '
        'MARK
        '
        Me.MARK.CanGrow = False
        Me.MARK.DataField = "MARK"
        Me.MARK.Height = 0.1574803!
        Me.MARK.Left = 5.850394!
        Me.MARK.MultiLine = False
        Me.MARK.Name = "MARK"
        Me.MARK.Style = "font-family: ＭＳ 明朝; font-size: 11pt; font-weight: normal; text-align: center; whi" &
            "te-space: nowrap"
        Me.MARK.Text = "123"
        Me.MARK.Top = 0.01968504!
        Me.MARK.Width = 0.1811024!
        '
        'SEPMARK
        '
        Me.SEPMARK.CanGrow = False
        Me.SEPMARK.DataField = "SEPMARK"
        Me.SEPMARK.Height = 0.1574803!
        Me.SEPMARK.Left = 0.4228347!
        Me.SEPMARK.MultiLine = False
        Me.SEPMARK.Name = "SEPMARK"
        Me.SEPMARK.Style = "font-family: ＭＳ 明朝; font-size: 11pt; font-weight: normal; text-align: center; whi" &
            "te-space: nowrap"
        Me.SEPMARK.Text = "123"
        Me.SEPMARK.Top = 0.01889764!
        Me.SEPMARK.Width = 0.1811024!
        '
        'PageFooter
        '
        Me.PageFooter.Controls.AddRange(New GrapeCity.ActiveReports.SectionReportModel.ARControl() {Me.HdLbl012, Me.CHGSUM, Me.CRGSUM, Me.Line1})
        Me.PageFooter.Height = 4.645669!
        Me.PageFooter.Name = "PageFooter"
        '
        'HdLbl012
        '
        Me.HdLbl012.CanGrow = False
        Me.HdLbl012.DataField = "HdLbl012"
        Me.HdLbl012.Height = 0.1692913!
        Me.HdLbl012.Left = 0.8614174!
        Me.HdLbl012.MultiLine = False
        Me.HdLbl012.Name = "HdLbl012"
        Me.HdLbl012.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl012.Tag = ""
        Me.HdLbl012.Text = "繰越残高"
        Me.HdLbl012.Top = 0.07165354!
        Me.HdLbl012.Width = 2.275984!
        '
        'CHGSUM
        '
        Me.CHGSUM.CanGrow = False
        Me.CHGSUM.DataField = "CHRG"
        Me.CHGSUM.Height = 0.1692913!
        Me.CHGSUM.Left = 3.191732!
        Me.CHGSUM.MultiLine = False
        Me.CHGSUM.Name = "CHGSUM"
        Me.CHGSUM.OutputFormat = resources.GetString("CHGSUM.OutputFormat")
        Me.CHGSUM.Style = "font-family: ＭＳ 明朝; font-size: 11pt; text-align: right; white-space: nowrap"
        Me.CHGSUM.Tag = ""
        Me.CHGSUM.Text = "999,999,999,999"
        Me.CHGSUM.Top = 0.07165355!
        Me.CHGSUM.Width = 1.259449!
        '
        'CRGSUM
        '
        Me.CRGSUM.CanGrow = False
        Me.CRGSUM.DataField = "CRDT"
        Me.CRGSUM.Height = 0.1692913!
        Me.CRGSUM.Left = 4.516536!
        Me.CRGSUM.MultiLine = False
        Me.CRGSUM.Name = "CRGSUM"
        Me.CRGSUM.OutputFormat = resources.GetString("CRGSUM.OutputFormat")
        Me.CRGSUM.Style = "font-family: ＭＳ 明朝; font-size: 11pt; text-align: right; white-space: nowrap"
        Me.CRGSUM.Tag = ""
        Me.CRGSUM.Text = "999,999,999,999"
        Me.CRGSUM.Top = 0.07165355!
        Me.CRGSUM.Width = 1.145669!
        '
        'Line1
        '
        Me.Line1.Height = 0.001574801!
        Me.Line1.Left = 0.0!
        Me.Line1.LineWeight = 1.0!
        Me.Line1.Name = "Line1"
        Me.Line1.Top = 0.01968504!
        Me.Line1.Width = 7.653543!
        Me.Line1.X1 = 0.0!
        Me.Line1.X2 = 7.653543!
        Me.Line1.Y1 = 0.02125984!
        Me.Line1.Y2 = 0.01968504!
        '
        'ReportHeader1
        '
        Me.ReportHeader1.Height = 0.0!
        Me.ReportHeader1.Name = "ReportHeader1"
        '
        'ReportFooter1
        '
        Me.ReportFooter1.Controls.AddRange(New GrapeCity.ActiveReports.SectionReportModel.ARControl() {Me.HdLbl013, Me.TextBox33, Me.HdLbl014, Me.HdLbl015, Me.TextBox36, Me.TextBox37, Me.HdLbl028, Me.HdLbl128, Me.MSTRDATA9, Me.HdLbl016, Me.MSTRDATA10, Me.HdLbl017, Me.HdLbl018, Me.CNM, Me.ADDR, Me.SEC, Me.HdLbl101, Me.PRNTNM, Me.HdLbl021, Me.HdLbl022, Me.ISSUNO, Me.MSTRDATA11, Me.Line4, Me.HdLbl023, Me.HdLbl200, Me.RECEIPTNM, Me.HdLbl024, Me.RECEIPTAMT, Me.HdLbl025, Me.RECEIPTMEMO, Me.HdLbl026, Me.MSTRDATA13, Me.MSTRDATA12, Me.HdLbl027, Me.RECEIPTDATE, Me.BLNO, Me.Shape1, Me.TextBox1, Me.TextBox3, Me.PAYDATA, Me.Line5, Me.Line6, Me.Line7, Me.Line8, Me.Line9, Me.HdLbl034, Me.HdLbl033, Me.PMINUS, Me.EXPPOINT, Me.HdLbl035, Me.PMINUS_E, Me.HdLbl035_E, Me.LNGCD, Me.HdLbl033_E, Me.EXPPOINT_E, Me.TITLESUMAMT1, Me.TITLESUMAMT2, Me.SUMAMT1, Me.SUMAMT2, Me.MARKSETUMEI, Me.HdLbl066, Me.HdLbl066_1, Me.PRTTAX1, Me.PRTTAX2, Me.HdLbl028_2, Me.HdLbl028_1, Me.TITLETAXNOT, Me.TITLEOTHER, Me.SUMOTHERAMT, Me.SUMTAXNOTAMT, Me.MSTRDATA25, Me.MSTRDATA27, Me.MSTRDATA28, Me.MSTRDATA29, Me.MSTRDATA26})
        Me.ReportFooter1.Height = 4.645669!
        Me.ReportFooter1.Name = "ReportFooter1"
        Me.ReportFooter1.PrintAtBottom = True
        '
        'HdLbl013
        '
        Me.HdLbl013.CanGrow = False
        Me.HdLbl013.DataField = "HdLbl013"
        Me.HdLbl013.Height = 0.1692913!
        Me.HdLbl013.Left = 1.403937!
        Me.HdLbl013.MultiLine = False
        Me.HdLbl013.Name = "HdLbl013"
        Me.HdLbl013.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl013.Tag = ""
        Me.HdLbl013.Text = "ご 請 求 金 額"
        Me.HdLbl013.Top = 0.03188977!
        Me.HdLbl013.Width = 1.824409!
        '
        'TextBox33
        '
        Me.TextBox33.CanGrow = False
        Me.TextBox33.DataField = "BNCE"
        Me.TextBox33.Height = 0.1692913!
        Me.TextBox33.Left = 3.296457!
        Me.TextBox33.MultiLine = False
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.OutputFormat = resources.GetString("TextBox33.OutputFormat")
        Me.TextBox33.Style = "font-family: ＭＳ 明朝; font-size: 11pt; text-align: right; text-justify: auto; verti" &
            "cal-align: middle; white-space: nowrap"
        Me.TextBox33.Tag = ""
        Me.TextBox33.Text = "9,999,999,999,999,999"
        Me.TextBox33.Top = 0.03188977!
        Me.TextBox33.Width = 1.647244!
        '
        'HdLbl014
        '
        Me.HdLbl014.CanGrow = False
        Me.HdLbl014.DataField = "HdLbl014"
        Me.HdLbl014.Height = 0.1692913!
        Me.HdLbl014.Left = 5.372835!
        Me.HdLbl014.MultiLine = False
        Me.HdLbl014.Name = "HdLbl014"
        Me.HdLbl014.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: right; white-space: nowrap"
        Me.HdLbl014.Tag = ""
        Me.HdLbl014.Text = "(内 消費税等:"
        Me.HdLbl014.Top = 0.03188977!
        Me.HdLbl014.Width = 1.105512!
        '
        'HdLbl015
        '
        Me.HdLbl015.CanGrow = False
        Me.HdLbl015.DataField = "HdLbl015"
        Me.HdLbl015.Height = 0.1692913!
        Me.HdLbl015.Left = 5.372835!
        Me.HdLbl015.MultiLine = False
        Me.HdLbl015.Name = "HdLbl015"
        Me.HdLbl015.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: right; white-space: nowrap"
        Me.HdLbl015.Tag = ""
        Me.HdLbl015.Text = "(内 宿泊税:"
        Me.HdLbl015.Top = 0.03188976!
        Me.HdLbl015.Width = 1.105512!
        '
        'TextBox36
        '
        Me.TextBox36.CanGrow = False
        Me.TextBox36.DataField = "PRTTAXAMT"
        Me.TextBox36.Height = 0.1692914!
        Me.TextBox36.Left = 6.601182!
        Me.TextBox36.MultiLine = False
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.OutputFormat = resources.GetString("TextBox36.OutputFormat")
        Me.TextBox36.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: right; white-space: nowrap"
        Me.TextBox36.Tag = ""
        Me.TextBox36.Text = "9,999,999"
        Me.TextBox36.Top = 0.03188977!
        Me.TextBox36.Width = 0.8188977!
        '
        'TextBox37
        '
        Me.TextBox37.CanGrow = False
        Me.TextBox37.DataField = "SUMOTAX"
        Me.TextBox37.Height = 0.1692914!
        Me.TextBox37.Left = 6.601182!
        Me.TextBox37.MultiLine = False
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.OutputFormat = resources.GetString("TextBox37.OutputFormat")
        Me.TextBox37.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: right; white-space: nowrap"
        Me.TextBox37.Tag = ""
        Me.TextBox37.Text = "9,999,999"
        Me.TextBox37.Top = 0.03188976!
        Me.TextBox37.Width = 0.8385825!
        '
        'HdLbl028
        '
        Me.HdLbl028.CanGrow = False
        Me.HdLbl028.DataField = "HdLbl028"
        Me.HdLbl028.Height = 0.1692913!
        Me.HdLbl028.Left = 7.470473!
        Me.HdLbl028.MultiLine = False
        Me.HdLbl028.Name = "HdLbl028"
        Me.HdLbl028.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: left; white-space: nowrap"
        Me.HdLbl028.Tag = ""
        Me.HdLbl028.Text = ")"
        Me.HdLbl028.Top = 0.03228347!
        Me.HdLbl028.Width = 0.1311021!
        '
        'HdLbl128
        '
        Me.HdLbl128.CanGrow = False
        Me.HdLbl128.DataField = "HdLbl028"
        Me.HdLbl128.Height = 0.1692913!
        Me.HdLbl128.Left = 7.470473!
        Me.HdLbl128.MultiLine = False
        Me.HdLbl128.Name = "HdLbl128"
        Me.HdLbl128.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: left; white-space: nowrap"
        Me.HdLbl128.Tag = ""
        Me.HdLbl128.Text = ")"
        Me.HdLbl128.Top = 0.03188976!
        Me.HdLbl128.Width = 0.1311021!
        '
        'MSTRDATA9
        '
        Me.MSTRDATA9.CanGrow = False
        Me.MSTRDATA9.DataField = "MSTRDATA9"
        Me.MSTRDATA9.Height = 0.1771654!
        Me.MSTRDATA9.Left = 0.1622048!
        Me.MSTRDATA9.MultiLine = False
        Me.MSTRDATA9.Name = "MSTRDATA9"
        Me.MSTRDATA9.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap; ddo-char-set: 1"
        Me.MSTRDATA9.Text = "NECホテル 東京"
        Me.MSTRDATA9.Top = 0.4728347!
        Me.MSTRDATA9.Width = 3.330709!
        '
        'HdLbl016
        '
        Me.HdLbl016.CanGrow = False
        Me.HdLbl016.DataField = "HdLbl016"
        Me.HdLbl016.Height = 0.1692913!
        Me.HdLbl016.Left = 0.1622048!
        Me.HdLbl016.MultiLine = False
        Me.HdLbl016.Name = "HdLbl016"
        Me.HdLbl016.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl016.Text = "会社名"
        Me.HdLbl016.Top = 1.400394!
        Me.HdLbl016.Width = 0.6830709!
        '
        'MSTRDATA10
        '
        Me.MSTRDATA10.CanGrow = False
        Me.MSTRDATA10.DataField = "MSTRDATA10"
        Me.MSTRDATA10.Height = 0.1771654!
        Me.MSTRDATA10.Left = 0.1622048!
        Me.MSTRDATA10.MultiLine = False
        Me.MSTRDATA10.Name = "MSTRDATA10"
        Me.MSTRDATA10.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap; ddo-char-set: 1"
        Me.MSTRDATA10.Text = "NECホテル 東京"
        Me.MSTRDATA10.Top = 0.6728346!
        Me.MSTRDATA10.Width = 3.330709!
        '
        'HdLbl017
        '
        Me.HdLbl017.CanGrow = False
        Me.HdLbl017.DataField = "HdLbl017"
        Me.HdLbl017.Height = 0.1692913!
        Me.HdLbl017.Left = 0.1622048!
        Me.HdLbl017.MultiLine = False
        Me.HdLbl017.Name = "HdLbl017"
        Me.HdLbl017.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl017.Text = "ご住所"
        Me.HdLbl017.Top = 1.569685!
        Me.HdLbl017.Width = 0.6830709!
        '
        'HdLbl018
        '
        Me.HdLbl018.CanGrow = False
        Me.HdLbl018.DataField = "HdLbl018"
        Me.HdLbl018.Height = 0.1692914!
        Me.HdLbl018.Left = 0.1622047!
        Me.HdLbl018.MultiLine = False
        Me.HdLbl018.Name = "HdLbl018"
        Me.HdLbl018.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl018.Text = "部課名"
        Me.HdLbl018.Top = 1.749213!
        Me.HdLbl018.Width = 0.6830709!
        '
        'CNM
        '
        Me.CNM.CanGrow = False
        Me.CNM.DataField = "CNM"
        Me.CNM.Height = 0.1692926!
        Me.CNM.Left = 0.0!
        Me.CNM.MultiLine = False
        Me.CNM.Name = "CNM"
        Me.CNM.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.CNM.Text = "わわわわわわわわわ0)わわわわわわわわわ1)"
        Me.CNM.Top = 1.400395!
        Me.CNM.Width = 3.918111!
        '
        'ADDR
        '
        Me.ADDR.CanGrow = False
        Me.ADDR.DataField = "ADDR"
        Me.ADDR.Height = 0.1692927!
        Me.ADDR.Left = 0.0!
        Me.ADDR.MultiLine = False
        Me.ADDR.Name = "ADDR"
        Me.ADDR.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.ADDR.Text = "わわわわわわわわわ0)わわわわわわわわわ1)"
        Me.ADDR.Top = 1.569685!
        Me.ADDR.Width = 3.918111!
        '
        'SEC
        '
        Me.SEC.CanGrow = False
        Me.SEC.DataField = "SEC"
        Me.SEC.Height = 0.1692927!
        Me.SEC.Left = 0.0!
        Me.SEC.MultiLine = False
        Me.SEC.Name = "SEC"
        Me.SEC.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.SEC.Text = "わわわわわわわわわ0)わわわわわわわわわ1)"
        Me.SEC.Top = 1.749214!
        Me.SEC.Width = 3.91811!
        '
        'HdLbl101
        '
        Me.HdLbl101.CanGrow = False
        Me.HdLbl101.DataField = "HdLbl029"
        Me.HdLbl101.Height = 0.1692915!
        Me.HdLbl101.Left = 0.1622047!
        Me.HdLbl101.MultiLine = False
        Me.HdLbl101.Name = "HdLbl101"
        Me.HdLbl101.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl101.Text = "お名前"
        Me.HdLbl101.Top = 1.92874!
        Me.HdLbl101.Width = 0.6830709!
        '
        'PRNTNM
        '
        Me.PRNTNM.CanGrow = False
        Me.PRNTNM.DataField = "PRNTNM"
        Me.PRNTNM.Height = 0.1692927!
        Me.PRNTNM.Left = 0.0!
        Me.PRNTNM.MultiLine = False
        Me.PRNTNM.Name = "PRNTNM"
        Me.PRNTNM.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.PRNTNM.Text = "わわわわわわわわわ0)わわわわわわわわわ1)わA"
        Me.PRNTNM.Top = 1.928741!
        Me.PRNTNM.Width = 3.91811!
        '
        'HdLbl021
        '
        Me.HdLbl021.CanGrow = False
        Me.HdLbl021.DataField = "HdLbl021"
        Me.HdLbl021.Height = 0.1692914!
        Me.HdLbl021.Left = 4.191339!
        Me.HdLbl021.MultiLine = False
        Me.HdLbl021.Name = "HdLbl021"
        Me.HdLbl021.Style = "font-family: ＭＳ 明朝; font-size: 12pt; white-space: nowrap"
        Me.HdLbl021.Text = "ご署名"
        Me.HdLbl021.Top = 1.738977!
        Me.HdLbl021.Width = 0.8078738!
        '
        'HdLbl022
        '
        Me.HdLbl022.CanGrow = False
        Me.HdLbl022.DataField = "HdLbl022"
        Me.HdLbl022.Height = 0.1692914!
        Me.HdLbl022.Left = 4.256693!
        Me.HdLbl022.MultiLine = False
        Me.HdLbl022.Name = "HdLbl022"
        Me.HdLbl022.Style = "font-family: ＭＳ 明朝; font-size: 9pt; white-space: nowrap"
        Me.HdLbl022.Text = "発行番号"
        Me.HdLbl022.Top = 1.090158!
        Me.HdLbl022.Width = 0.6830707!
        '
        'ISSUNO
        '
        Me.ISSUNO.CanGrow = False
        Me.ISSUNO.DataField = "ISSUNO"
        Me.ISSUNO.Height = 0.3385826!
        Me.ISSUNO.Left = 5.154331!
        Me.ISSUNO.Name = "ISSUNO"
        Me.ISSUNO.Style = "font-family: ＭＳ 明朝; font-size: 9pt; white-space: inherit"
        Me.ISSUNO.Text = "わわわわわわわわわ0)わわわわわわわわわ1)わわわわわわ"
        Me.ISSUNO.Top = 1.090157!
        Me.ISSUNO.Width = 2.447244!
        '
        'MSTRDATA11
        '
        Me.MSTRDATA11.CanGrow = False
        Me.MSTRDATA11.DataField = "MSTRDATA11"
        Me.MSTRDATA11.Height = 0.1771654!
        Me.MSTRDATA11.Left = 0.1622048!
        Me.MSTRDATA11.MultiLine = False
        Me.MSTRDATA11.Name = "MSTRDATA11"
        Me.MSTRDATA11.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap; ddo-char-set: 1"
        Me.MSTRDATA11.Text = "NECホテル 東京"
        Me.MSTRDATA11.Top = 0.9035433!
        Me.MSTRDATA11.Width = 3.330709!
        '
        'Line4
        '
        Me.Line4.Height = 0.0!
        Me.Line4.Left = 0.0!
        Me.Line4.LineStyle = GrapeCity.ActiveReports.SectionReportModel.LineStyle.Dash
        Me.Line4.LineWeight = 1.0!
        Me.Line4.Name = "Line4"
        Me.Line4.Top = 2.267717!
        Me.Line4.Width = 7.471261!
        Me.Line4.X1 = 0.0!
        Me.Line4.X2 = 7.471261!
        Me.Line4.Y1 = 2.267717!
        Me.Line4.Y2 = 2.267717!
        '
        'HdLbl023
        '
        Me.HdLbl023.CanGrow = False
        Me.HdLbl023.DataField = "HdLbl023"
        Me.HdLbl023.Height = 0.2362206!
        Me.HdLbl023.Left = 1.41063!
        Me.HdLbl023.MultiLine = False
        Me.HdLbl023.Name = "HdLbl023"
        Me.HdLbl023.Style = "font-family: ＭＳ 明朝; font-size: 16pt; text-align: center; white-space: nowrap"
        Me.HdLbl023.Text = "領　収　書"
        Me.HdLbl023.Top = 2.377166!
        Me.HdLbl023.Width = 3.662205!
        '
        'HdLbl200
        '
        Me.HdLbl200.CanGrow = False
        Me.HdLbl200.DataField = "HdLbl001"
        Me.HdLbl200.Height = 0.1692915!
        Me.HdLbl200.Left = 0.0000002384186!
        Me.HdLbl200.MultiLine = False
        Me.HdLbl200.Name = "HdLbl200"
        Me.HdLbl200.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl200.Text = "お名前"
        Me.HdLbl200.Top = 2.575198!
        Me.HdLbl200.Width = 0.5059053!
        '
        'RECEIPTNM
        '
        Me.RECEIPTNM.CanGrow = False
        Me.RECEIPTNM.DataField = "RECEIPTNM"
        Me.RECEIPTNM.Height = 0.1692927!
        Me.RECEIPTNM.Left = 0.6141732!
        Me.RECEIPTNM.MultiLine = False
        Me.RECEIPTNM.Name = "RECEIPTNM"
        Me.RECEIPTNM.Style = "font-family: ＭＳ 明朝; font-size: 11pt; text-align: left; white-space: nowrap"
        Me.RECEIPTNM.Text = "0123456789012345678901234567890123456789"
        Me.RECEIPTNM.Top = 2.673228!
        Me.RECEIPTNM.Width = 4.030709!
        '
        'HdLbl024
        '
        Me.HdLbl024.CanGrow = False
        Me.HdLbl024.DataField = "HdLbl024"
        Me.HdLbl024.Height = 0.1692915!
        Me.HdLbl024.Left = 0.0000002384186!
        Me.HdLbl024.MultiLine = False
        Me.HdLbl024.Name = "HdLbl024"
        Me.HdLbl024.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl024.Text = "金額"
        Me.HdLbl024.Top = 2.948032!
        Me.HdLbl024.Width = 0.8086612!
        '
        'RECEIPTAMT
        '
        Me.RECEIPTAMT.CanGrow = False
        Me.RECEIPTAMT.DataField = "RECEIPTAMT"
        Me.RECEIPTAMT.Height = 0.2409449!
        Me.RECEIPTAMT.Left = 0.8086605!
        Me.RECEIPTAMT.MultiLine = False
        Me.RECEIPTAMT.Name = "RECEIPTAMT"
        Me.RECEIPTAMT.Style = "font-family: ＭＳ 明朝; font-size: 16pt; text-align: center; white-space: nowrap"
        Me.RECEIPTAMT.Text = "9,999,999,999,999"
        Me.RECEIPTAMT.Top = 3.040945!
        Me.RECEIPTAMT.Width = 3.121654!
        '
        'HdLbl025
        '
        Me.HdLbl025.CanGrow = False
        Me.HdLbl025.DataField = "HdLbl025"
        Me.HdLbl025.Height = 0.1692915!
        Me.HdLbl025.Left = 0.0000002384186!
        Me.HdLbl025.MultiLine = False
        Me.HdLbl025.Name = "HdLbl025"
        Me.HdLbl025.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl025.Text = "但し"
        Me.HdLbl025.Top = 3.34134!
        Me.HdLbl025.Width = 1.006693!
        '
        'RECEIPTMEMO
        '
        Me.RECEIPTMEMO.CanGrow = False
        Me.RECEIPTMEMO.DataField = "RECEIPTMEMO"
        Me.RECEIPTMEMO.Height = 0.1692927!
        Me.RECEIPTMEMO.Left = 1.006693!
        Me.RECEIPTMEMO.MultiLine = False
        Me.RECEIPTMEMO.Name = "RECEIPTMEMO"
        Me.RECEIPTMEMO.Style = "font-family: ＭＳ 明朝; font-size: 11pt; text-align: left; white-space: nowrap"
        Me.RECEIPTMEMO.Text = "わわわわわわわわわ0)わわわわわわわわわ1)"
        Me.RECEIPTMEMO.Top = 3.433465!
        Me.RECEIPTMEMO.Width = 2.923621!
        '
        'HdLbl026
        '
        Me.HdLbl026.CanGrow = False
        Me.HdLbl026.DataField = "HdLbl026"
        Me.HdLbl026.Height = 0.1692927!
        Me.HdLbl026.Left = 0.2212599!
        Me.HdLbl026.MultiLine = False
        Me.HdLbl026.Name = "HdLbl026"
        Me.HdLbl026.Style = "font-family: ＭＳ 明朝; font-size: 9pt; white-space: nowrap"
        Me.HdLbl026.Text = "上記金額正に領収いたしました。"
        Me.HdLbl026.Top = 3.690158!
        Me.HdLbl026.Width = 3.127559!
        '
        'MSTRDATA13
        '
        Me.MSTRDATA13.CanGrow = False
        Me.MSTRDATA13.DataField = "MSTRDATA13"
        Me.MSTRDATA13.Height = 0.1771655!
        Me.MSTRDATA13.Left = 1.006693!
        Me.MSTRDATA13.MultiLine = False
        Me.MSTRDATA13.Name = "MSTRDATA13"
        Me.MSTRDATA13.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap; ddo-char-set: 1"
        Me.MSTRDATA13.Text = "NECホテル 東京"
        Me.MSTRDATA13.Top = 4.172441!
        Me.MSTRDATA13.Width = 3.330709!
        '
        'MSTRDATA12
        '
        Me.MSTRDATA12.CanGrow = False
        Me.MSTRDATA12.DataField = "MSTRDATA12"
        Me.MSTRDATA12.Height = 0.1771653!
        Me.MSTRDATA12.Left = 1.006693!
        Me.MSTRDATA12.MultiLine = False
        Me.MSTRDATA12.Name = "MSTRDATA12"
        Me.MSTRDATA12.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap; ddo-char-set: 1"
        Me.MSTRDATA12.Text = "NECホテル 東京"
        Me.MSTRDATA12.Top = 3.92126!
        Me.MSTRDATA12.Width = 3.330709!
        '
        'HdLbl027
        '
        Me.HdLbl027.CanGrow = False
        Me.HdLbl027.DataField = "HdLbl027"
        Me.HdLbl027.Height = 0.1692915!
        Me.HdLbl027.Left = 5.12126!
        Me.HdLbl027.MultiLine = False
        Me.HdLbl027.Name = "HdLbl027"
        Me.HdLbl027.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.HdLbl027.Text = "日付"
        Me.HdLbl027.Top = 2.46811!
        Me.HdLbl027.Width = 0.3948822!
        '
        'RECEIPTDATE
        '
        Me.RECEIPTDATE.CanGrow = False
        Me.RECEIPTDATE.DataField = "RECEIPTDATE"
        Me.RECEIPTDATE.Height = 0.1692927!
        Me.RECEIPTDATE.Left = 5.554331!
        Me.RECEIPTDATE.MultiLine = False
        Me.RECEIPTDATE.Name = "RECEIPTDATE"
        Me.RECEIPTDATE.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.RECEIPTDATE.Text = "9999/99/99"
        Me.RECEIPTDATE.Top = 2.468111!
        Me.RECEIPTDATE.Width = 0.8011808!
        '
        'BLNO
        '
        Me.BLNO.CanGrow = False
        Me.BLNO.DataField = "BLNO"
        Me.BLNO.Height = 0.1692927!
        Me.BLNO.Left = 6.481496!
        Me.BLNO.MultiLine = False
        Me.BLNO.Name = "BLNO"
        Me.BLNO.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.BLNO.Text = "012345678901"
        Me.BLNO.Top = 2.468111!
        Me.BLNO.Width = 1.007481!
        '
        'Shape1
        '
        Me.Shape1.Height = 0.7003937!
        Me.Shape1.Left = 6.143308!
        Me.Shape1.Name = "Shape1"
        Me.Shape1.RoundingRadius = New GrapeCity.ActiveReports.Controls.CornersRadius(9.999999!)
        Me.Shape1.Top = 2.948032!
        Me.Shape1.Width = 0.7964563!
        '
        'TextBox1
        '
        Me.TextBox1.CanGrow = False
        Me.TextBox1.Height = 0.1692915!
        Me.TextBox1.Left = 6.24252!
        Me.TextBox1.MultiLine = False
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Style = "font-family: ＭＳ 明朝; font-size: 10pt; text-align: center; white-space: nowrap"
        Me.TextBox1.Text = "収入"
        Me.TextBox1.Top = 3.116142!
        Me.TextBox1.Width = 0.5893698!
        '
        'TextBox3
        '
        Me.TextBox3.CanGrow = False
        Me.TextBox3.Height = 0.1692915!
        Me.TextBox3.Left = 6.24252!
        Me.TextBox3.MultiLine = False
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Style = "font-family: ＭＳ 明朝; font-size: 10pt; text-align: center; white-space: nowrap"
        Me.TextBox3.Text = "印紙"
        Me.TextBox3.Top = 3.275197!
        Me.TextBox3.Width = 0.5893698!
        '
        'PAYDATA
        '
        Me.PAYDATA.CanGrow = False
        Me.PAYDATA.DataField = "CPAYDATA"
        Me.PAYDATA.Height = 0.1692913!
        Me.PAYDATA.Left = 0.1622048!
        Me.PAYDATA.MultiLine = False
        Me.PAYDATA.Name = "PAYDATA"
        Me.PAYDATA.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.PAYDATA.Text = "01234567890123456789"
        Me.PAYDATA.Top = 1.175197!
        Me.PAYDATA.Width = 1.633858!
        '
        'Line5
        '
        Me.Line5.Height = 0.0!
        Me.Line5.Left = 4.191339!
        Me.Line5.LineWeight = 1.0!
        Me.Line5.Name = "Line5"
        Me.Line5.Top = 2.03937!
        Me.Line5.Width = 3.279922!
        Me.Line5.X1 = 4.191339!
        Me.Line5.X2 = 7.471261!
        Me.Line5.Y1 = 2.03937!
        Me.Line5.Y2 = 2.03937!
        '
        'Line6
        '
        Me.Line6.Height = 0.0007870197!
        Me.Line6.Left = 0.0000002384186!
        Me.Line6.LineWeight = 1.0!
        Me.Line6.Name = "Line6"
        Me.Line6.Top = 2.88819!
        Me.Line6.Width = 3.976378!
        Me.Line6.X1 = 0.0000002384186!
        Me.Line6.X2 = 3.976378!
        Me.Line6.Y1 = 2.88819!
        Me.Line6.Y2 = 2.888977!
        '
        'Line7
        '
        Me.Line7.Height = 0.0007870197!
        Me.Line7.Left = 0.0000002384186!
        Me.Line7.LineWeight = 1.0!
        Me.Line7.Name = "Line7"
        Me.Line7.Top = 3.301576!
        Me.Line7.Width = 3.976378!
        Me.Line7.X1 = 0.0000002384186!
        Me.Line7.X2 = 3.976378!
        Me.Line7.Y1 = 3.302363!
        Me.Line7.Y2 = 3.301576!
        '
        'Line8
        '
        Me.Line8.Height = 0.001182079!
        Me.Line8.Left = 0.0000002384186!
        Me.Line8.LineWeight = 1.0!
        Me.Line8.Name = "Line8"
        Me.Line8.Top = 3.647245!
        Me.Line8.Width = 3.976378!
        Me.Line8.X1 = 0.0000002384186!
        Me.Line8.X2 = 3.976378!
        Me.Line8.Y1 = 3.647245!
        Me.Line8.Y2 = 3.648427!
        '
        'Line9
        '
        Me.Line9.Height = 0.0!
        Me.Line9.Left = 0.0!
        Me.Line9.LineWeight = 1.0!
        Me.Line9.Name = "Line9"
        Me.Line9.Top = 0.01968504!
        Me.Line9.Width = 7.652756!
        Me.Line9.X1 = 0.0!
        Me.Line9.X2 = 7.652756!
        Me.Line9.Y1 = 0.01968504!
        Me.Line9.Y2 = 0.01968504!
        '
        'HdLbl034
        '
        Me.HdLbl034.CanGrow = False
        Me.HdLbl034.DataField = "HdLbl034"
        Me.HdLbl034.Height = 0.1692913!
        Me.HdLbl034.Left = 4.901575!
        Me.HdLbl034.MultiLine = False
        Me.HdLbl034.Name = "HdLbl034"
        Me.HdLbl034.Style = "font-family: ＭＳ 明朝; font-size: 9pt; vertical-align: middle; white-space: nowrap; " &
            "ddo-char-set: 128"
        Me.HdLbl034.Text = "今回までP:"
        Me.HdLbl034.Top = 1.455118!
        Me.HdLbl034.Width = 0.6259843!
        '
        'HdLbl033
        '
        Me.HdLbl033.CanGrow = False
        Me.HdLbl033.DataField = "HdLbl033"
        Me.HdLbl033.Height = 0.1692913!
        Me.HdLbl033.Left = 4.009842!
        Me.HdLbl033.MultiLine = False
        Me.HdLbl033.Name = "HdLbl033"
        Me.HdLbl033.Style = "font-family: ＭＳ 明朝; font-size: 9pt; vertical-align: middle; white-space: nowrap"
        Me.HdLbl033.Text = "JRHMポイントテ"
        Me.HdLbl033.Top = 1.455118!
        Me.HdLbl033.Width = 0.8665357!
        '
        'PMINUS
        '
        Me.PMINUS.CanGrow = False
        Me.PMINUS.DataField = "PMINUS"
        Me.PMINUS.Height = 0.1692914!
        Me.PMINUS.Left = 5.617008!
        Me.PMINUS.MultiLine = False
        Me.PMINUS.Name = "PMINUS"
        Me.PMINUS.OutputFormat = resources.GetString("PMINUS.OutputFormat")
        Me.PMINUS.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: left; vertical-align: middle; whi" &
            "te-space: nowrap"
        Me.PMINUS.Tag = ""
        Me.PMINUS.Text = "9,999,999"
        Me.PMINUS.Top = 1.456693!
        Me.PMINUS.Width = 0.7551181!
        '
        'EXPPOINT
        '
        Me.EXPPOINT.CanGrow = False
        Me.EXPPOINT.DataField = "EXPPOINT"
        Me.EXPPOINT.Height = 0.1692914!
        Me.EXPPOINT.Left = 6.868937!
        Me.EXPPOINT.MultiLine = False
        Me.EXPPOINT.Name = "EXPPOINT"
        Me.EXPPOINT.OutputFormat = resources.GetString("EXPPOINT.OutputFormat")
        Me.EXPPOINT.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: left; vertical-align: middle; whi" &
            "te-space: nowrap"
        Me.EXPPOINT.Tag = ""
        Me.EXPPOINT.Text = "9,999,999"
        Me.EXPPOINT.Top = 1.456844!
        Me.EXPPOINT.Width = 0.724409!
        '
        'HdLbl035
        '
        Me.HdLbl035.CanGrow = False
        Me.HdLbl035.DataField = "HdLbl035"
        Me.HdLbl035.Height = 0.1692913!
        Me.HdLbl035.Left = 6.425197!
        Me.HdLbl035.MultiLine = False
        Me.HdLbl035.Name = "HdLbl035"
        Me.HdLbl035.Style = "font-family: ＭＳ 明朝; font-size: 9pt; vertical-align: middle; white-space: nowrap; " &
            "ddo-char-set: 128"
        Me.HdLbl035.Text = "今回P:"
        Me.HdLbl035.Top = 1.455118!
        Me.HdLbl035.Width = 0.3858268!
        '
        'PMINUS_E
        '
        Me.PMINUS_E.CanGrow = False
        Me.PMINUS_E.DataField = "PMINUS"
        Me.PMINUS_E.Height = 0.1692914!
        Me.PMINUS_E.Left = 5.162007!
        Me.PMINUS_E.MultiLine = False
        Me.PMINUS_E.Name = "PMINUS_E"
        Me.PMINUS_E.OutputFormat = resources.GetString("PMINUS_E.OutputFormat")
        Me.PMINUS_E.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: left; vertical-align: middle; whi" &
            "te-space: nowrap"
        Me.PMINUS_E.Tag = ""
        Me.PMINUS_E.Text = "9,999,999"
        Me.PMINUS_E.Top = 1.456693!
        Me.PMINUS_E.Width = 0.7551181!
        '
        'HdLbl035_E
        '
        Me.HdLbl035_E.CanGrow = False
        Me.HdLbl035_E.DataField = "HdLbl035"
        Me.HdLbl035_E.Height = 0.1692913!
        Me.HdLbl035_E.Left = 6.157481!
        Me.HdLbl035_E.MultiLine = False
        Me.HdLbl035_E.Name = "HdLbl035_E"
        Me.HdLbl035_E.Style = "font-family: ＭＳ 明朝; font-size: 9pt; vertical-align: middle; white-space: nowrap; " &
            "ddo-char-set: 128"
        Me.HdLbl035_E.Text = "ADD POINT:"
        Me.HdLbl035_E.Top = 1.455118!
        Me.HdLbl035_E.Width = 0.6889764!
        '
        'LNGCD
        '
        Me.LNGCD.CanGrow = False
        Me.LNGCD.DataField = "LNGCD"
        Me.LNGCD.Height = 0.0!
        Me.LNGCD.Left = 5.130008!
        Me.LNGCD.MultiLine = False
        Me.LNGCD.Name = "LNGCD"
        Me.LNGCD.Style = "font-family: ＭＳ 明朝; font-size: 11pt; white-space: nowrap"
        Me.LNGCD.Text = Nothing
        Me.LNGCD.Top = 1.410606!
        Me.LNGCD.Visible = False
        Me.LNGCD.Width = 0.0!
        '
        'HdLbl033_E
        '
        Me.HdLbl033_E.CanGrow = False
        Me.HdLbl033_E.DataField = "HdLbl033"
        Me.HdLbl033_E.Height = 0.1692913!
        Me.HdLbl033_E.Left = 4.255906!
        Me.HdLbl033_E.MultiLine = False
        Me.HdLbl033_E.Name = "HdLbl033_E"
        Me.HdLbl033_E.Style = "font-family: ＭＳ 明朝; font-size: 9pt; vertical-align: middle; white-space: nowrap"
        Me.HdLbl033_E.Text = "JRHM POINT:"
        Me.HdLbl033_E.Top = 1.455118!
        Me.HdLbl033_E.Width = 0.742126!
        '
        'EXPPOINT_E
        '
        Me.EXPPOINT_E.CanGrow = False
        Me.EXPPOINT_E.DataField = "EXPPOINT"
        Me.EXPPOINT_E.Height = 0.1692914!
        Me.EXPPOINT_E.Left = 6.869008!
        Me.EXPPOINT_E.MultiLine = False
        Me.EXPPOINT_E.Name = "EXPPOINT_E"
        Me.EXPPOINT_E.OutputFormat = resources.GetString("EXPPOINT_E.OutputFormat")
        Me.EXPPOINT_E.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: left; vertical-align: middle; whi" &
            "te-space: nowrap"
        Me.EXPPOINT_E.Tag = ""
        Me.EXPPOINT_E.Text = "9,999,999"
        Me.EXPPOINT_E.Top = 1.456693!
        Me.EXPPOINT_E.Width = 0.724409!
        '
        'TITLESUMAMT1
        '
        Me.TITLESUMAMT1.CanGrow = False
        Me.TITLESUMAMT1.DataField = "TITLESUMAMT1"
        Me.TITLESUMAMT1.Height = 0.1692913!
        Me.TITLESUMAMT1.Left = 3.681103!
        Me.TITLESUMAMT1.MultiLine = False
        Me.TITLESUMAMT1.Name = "TITLESUMAMT1"
        Me.TITLESUMAMT1.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: right; white-space: nowrap; ddo-c" &
            "har-set: 1"
        Me.TITLESUMAMT1.Tag = ""
        Me.TITLESUMAMT1.Text = "10%対象"
        Me.TITLESUMAMT1.Top = 0.2086614!
        Me.TITLESUMAMT1.Width = 1.259843!
        '
        'TITLESUMAMT2
        '
        Me.TITLESUMAMT2.CanGrow = False
        Me.TITLESUMAMT2.DataField = "TITLESUMAMT2"
        Me.TITLESUMAMT2.Height = 0.1692913!
        Me.TITLESUMAMT2.Left = 3.681103!
        Me.TITLESUMAMT2.MultiLine = False
        Me.TITLESUMAMT2.Name = "TITLESUMAMT2"
        Me.TITLESUMAMT2.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: right; white-space: nowrap; ddo-c" &
            "har-set: 1"
        Me.TITLESUMAMT2.Tag = ""
        Me.TITLESUMAMT2.Text = "8%対象"
        Me.TITLESUMAMT2.Top = 0.3850394!
        Me.TITLESUMAMT2.Width = 1.259842!
        '
        'SUMAMT1
        '
        Me.SUMAMT1.CanGrow = False
        Me.SUMAMT1.DataField = "SUMAMT1"
        Me.SUMAMT1.Height = 0.1692913!
        Me.SUMAMT1.Left = 4.872441!
        Me.SUMAMT1.MultiLine = False
        Me.SUMAMT1.Name = "SUMAMT1"
        Me.SUMAMT1.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: right; white-space: nowrap; ddo-c" &
            "har-set: 1"
        Me.SUMAMT1.Tag = ""
        Me.SUMAMT1.Text = "999,999,999"
        Me.SUMAMT1.Top = 0.2086614!
        Me.SUMAMT1.Width = 0.8366145!
        '
        'SUMAMT2
        '
        Me.SUMAMT2.CanGrow = False
        Me.SUMAMT2.DataField = "SUMAMT2"
        Me.SUMAMT2.Height = 0.1692913!
        Me.SUMAMT2.Left = 4.872441!
        Me.SUMAMT2.MultiLine = False
        Me.SUMAMT2.Name = "SUMAMT2"
        Me.SUMAMT2.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: right; white-space: nowrap; ddo-c" &
            "har-set: 1"
        Me.SUMAMT2.Tag = ""
        Me.SUMAMT2.Text = "999,999,999"
        Me.SUMAMT2.Top = 0.3850394!
        Me.SUMAMT2.Width = 0.8366145!
        '
        'MARKSETUMEI
        '
        Me.MARKSETUMEI.CanGrow = False
        Me.MARKSETUMEI.DataField = "MARKSETUMEI"
        Me.MARKSETUMEI.Height = 0.1692913!
        Me.MARKSETUMEI.Left = 5.57874!
        Me.MARKSETUMEI.MultiLine = False
        Me.MARKSETUMEI.Name = "MARKSETUMEI"
        Me.MARKSETUMEI.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: right; white-space: inherit; ddo-" &
            "char-set: 1"
        Me.MARKSETUMEI.Tag = ""
        Me.MARKSETUMEI.Text = "▲　軽減税率　　■　新12"
        Me.MARKSETUMEI.Top = 0.9094488!
        Me.MARKSETUMEI.Width = 1.862205!
        '
        'HdLbl066
        '
        Me.HdLbl066.CanGrow = False
        Me.HdLbl066.DataField = "HdLbl066"
        Me.HdLbl066.Height = 0.1692913!
        Me.HdLbl066.Left = 5.703939!
        Me.HdLbl066.MultiLine = False
        Me.HdLbl066.Name = "HdLbl066"
        Me.HdLbl066.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: right; white-space: nowrap; ddo-c" &
            "har-set: 1"
        Me.HdLbl066.Tag = ""
        Me.HdLbl066.Text = "(CONSUMPTION TAX"
        Me.HdLbl066.Top = 0.2086614!
        Me.HdLbl066.Width = 1.037795!
        '
        'HdLbl066_1
        '
        Me.HdLbl066_1.CanGrow = False
        Me.HdLbl066_1.DataField = "HdLbl066"
        Me.HdLbl066_1.Height = 0.1692913!
        Me.HdLbl066_1.Left = 5.703939!
        Me.HdLbl066_1.MultiLine = False
        Me.HdLbl066_1.Name = "HdLbl066_1"
        Me.HdLbl066_1.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: right; white-space: nowrap; ddo-c" &
            "har-set: 1"
        Me.HdLbl066_1.Tag = ""
        Me.HdLbl066_1.Text = "消費税"
        Me.HdLbl066_1.Top = 0.3850394!
        Me.HdLbl066_1.Width = 1.037795!
        '
        'PRTTAX1
        '
        Me.PRTTAX1.CanGrow = False
        Me.PRTTAX1.DataField = "PRTTAX1"
        Me.PRTTAX1.Height = 0.1692913!
        Me.PRTTAX1.Left = 6.772443!
        Me.PRTTAX1.MultiLine = False
        Me.PRTTAX1.Name = "PRTTAX1"
        Me.PRTTAX1.OutputFormat = resources.GetString("PRTTAX1.OutputFormat")
        Me.PRTTAX1.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: right; white-space: nowrap; ddo-c" &
            "har-set: 1"
        Me.PRTTAX1.Tag = ""
        Me.PRTTAX1.Text = "999,999,999"
        Me.PRTTAX1.Top = 0.2086614!
        Me.PRTTAX1.Width = 0.6685053!
        '
        'PRTTAX2
        '
        Me.PRTTAX2.CanGrow = False
        Me.PRTTAX2.DataField = "PRTTAX2"
        Me.PRTTAX2.Height = 0.1692913!
        Me.PRTTAX2.Left = 6.772443!
        Me.PRTTAX2.MultiLine = False
        Me.PRTTAX2.Name = "PRTTAX2"
        Me.PRTTAX2.OutputFormat = resources.GetString("PRTTAX2.OutputFormat")
        Me.PRTTAX2.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: right; white-space: nowrap; ddo-c" &
            "har-set: 1"
        Me.PRTTAX2.Tag = ""
        Me.PRTTAX2.Text = "999,999,999"
        Me.PRTTAX2.Top = 0.3850394!
        Me.PRTTAX2.Width = 0.6685053!
        '
        'HdLbl028_2
        '
        Me.HdLbl028_2.CanGrow = False
        Me.HdLbl028_2.DataField = "HdLbl028"
        Me.HdLbl028_2.Height = 0.1692913!
        Me.HdLbl028_2.Left = 7.473623!
        Me.HdLbl028_2.MultiLine = False
        Me.HdLbl028_2.Name = "HdLbl028_2"
        Me.HdLbl028_2.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: left; white-space: nowrap; ddo-ch" &
            "ar-set: 1"
        Me.HdLbl028_2.Tag = ""
        Me.HdLbl028_2.Text = ")"
        Me.HdLbl028_2.Top = 0.3850394!
        Me.HdLbl028_2.Width = 0.131102!
        '
        'HdLbl028_1
        '
        Me.HdLbl028_1.CanGrow = False
        Me.HdLbl028_1.DataField = "HdLbl028"
        Me.HdLbl028_1.Height = 0.1692913!
        Me.HdLbl028_1.Left = 7.473623!
        Me.HdLbl028_1.MultiLine = False
        Me.HdLbl028_1.Name = "HdLbl028_1"
        Me.HdLbl028_1.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: left; white-space: nowrap; ddo-ch" &
            "ar-set: 1"
        Me.HdLbl028_1.Tag = ""
        Me.HdLbl028_1.Text = ")"
        Me.HdLbl028_1.Top = 0.2086614!
        Me.HdLbl028_1.Width = 0.131102!
        '
        'TITLETAXNOT
        '
        Me.TITLETAXNOT.CanGrow = False
        Me.TITLETAXNOT.DataField = "TITLETAXNOT"
        Me.TITLETAXNOT.Height = 0.1692913!
        Me.TITLETAXNOT.Left = 3.681103!
        Me.TITLETAXNOT.MultiLine = False
        Me.TITLETAXNOT.Name = "TITLETAXNOT"
        Me.TITLETAXNOT.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: right; white-space: nowrap; ddo-c" &
            "har-set: 1"
        Me.TITLETAXNOT.Tag = ""
        Me.TITLETAXNOT.Text = "消費税課税対象外"
        Me.TITLETAXNOT.Top = 0.5614174!
        Me.TITLETAXNOT.Width = 1.259843!
        '
        'TITLEOTHER
        '
        Me.TITLEOTHER.CanGrow = False
        Me.TITLEOTHER.DataField = "TITLEOTHER"
        Me.TITLEOTHER.Height = 0.1692913!
        Me.TITLEOTHER.Left = 3.681103!
        Me.TITLEOTHER.MultiLine = False
        Me.TITLEOTHER.Name = "TITLEOTHER"
        Me.TITLEOTHER.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: right; white-space: nowrap; ddo-c" &
            "har-set: 1"
        Me.TITLEOTHER.Tag = ""
        Me.TITLEOTHER.Text = "そのた"
        Me.TITLEOTHER.Top = 0.7433072!
        Me.TITLEOTHER.Width = 1.259842!
        '
        'SUMOTHERAMT
        '
        Me.SUMOTHERAMT.CanGrow = False
        Me.SUMOTHERAMT.DataField = "SUMOTHERAMT"
        Me.SUMOTHERAMT.Height = 0.1692913!
        Me.SUMOTHERAMT.Left = 6.604333!
        Me.SUMOTHERAMT.MultiLine = False
        Me.SUMOTHERAMT.Name = "SUMOTHERAMT"
        Me.SUMOTHERAMT.OutputFormat = resources.GetString("SUMOTHERAMT.OutputFormat")
        Me.SUMOTHERAMT.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: right; white-space: nowrap; ddo-c" &
            "har-set: 1"
        Me.SUMOTHERAMT.Tag = ""
        Me.SUMOTHERAMT.Text = "999,999,999"
        Me.SUMOTHERAMT.Top = 0.7433072!
        Me.SUMOTHERAMT.Width = 0.8366145!
        '
        'SUMTAXNOTAMT
        '
        Me.SUMTAXNOTAMT.CanGrow = False
        Me.SUMTAXNOTAMT.DataField = "SUMTAXNOTAMT"
        Me.SUMTAXNOTAMT.Height = 0.1692913!
        Me.SUMTAXNOTAMT.Left = 6.604333!
        Me.SUMTAXNOTAMT.MultiLine = False
        Me.SUMTAXNOTAMT.Name = "SUMTAXNOTAMT"
        Me.SUMTAXNOTAMT.OutputFormat = resources.GetString("SUMTAXNOTAMT.OutputFormat")
        Me.SUMTAXNOTAMT.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: right; white-space: nowrap; ddo-c" &
            "har-set: 1"
        Me.SUMTAXNOTAMT.Tag = ""
        Me.SUMTAXNOTAMT.Text = "999,999,999"
        Me.SUMTAXNOTAMT.Top = 0.5614174!
        Me.SUMTAXNOTAMT.Width = 0.8366145!
        '
        'MSTRDATA25
        '
        Me.MSTRDATA25.CanGrow = False
        Me.MSTRDATA25.DataField = "MSTRDATA25"
        Me.MSTRDATA25.Height = 0.1692913!
        Me.MSTRDATA25.Left = 0.1622049!
        Me.MSTRDATA25.MultiLine = False
        Me.MSTRDATA25.Name = "MSTRDATA25"
        Me.MSTRDATA25.Style = "font-family: ＭＳ 明朝; font-size: 11pt; text-align: left; white-space: nowrap; ddo-c" &
            "har-set: 1"
        Me.MSTRDATA25.Tag = ""
        Me.MSTRDATA25.Text = "※仕入税額控除対象"
        Me.MSTRDATA25.Top = 0.2523622!
        Me.MSTRDATA25.Width = 1.097638!
        '
        'MSTRDATA27
        '
        Me.MSTRDATA27.CanGrow = False
        Me.MSTRDATA27.DataField = "MSTRDATA27"
        Me.MSTRDATA27.Height = 0.1692913!
        Me.MSTRDATA27.Left = 0.4389765!
        Me.MSTRDATA27.MultiLine = False
        Me.MSTRDATA27.Name = "MSTRDATA27"
        Me.MSTRDATA27.Style = "font-family: ＭＳ 明朝; font-size: 11pt; text-align: left; white-space: nowrap; ddo-c" &
            "har-set: 1"
        Me.MSTRDATA27.Tag = ""
        Me.MSTRDATA27.Text = "※仕入税額控除対象"
        Me.MSTRDATA27.Top = 0.2523622!
        Me.MSTRDATA27.Width = 1.098425!
        '
        'MSTRDATA28
        '
        Me.MSTRDATA28.CanGrow = False
        Me.MSTRDATA28.DataField = "MSTRDATA28"
        Me.MSTRDATA28.Height = 0.1692913!
        Me.MSTRDATA28.Left = 0.831103!
        Me.MSTRDATA28.MultiLine = False
        Me.MSTRDATA28.Name = "MSTRDATA28"
        Me.MSTRDATA28.Style = "font-family: ＭＳ 明朝; font-size: 11pt; text-align: left; white-space: nowrap; ddo-c" &
            "har-set: 1"
        Me.MSTRDATA28.Tag = ""
        Me.MSTRDATA28.Text = "※仕入税額控除対象"
        Me.MSTRDATA28.Top = 0.2523622!
        Me.MSTRDATA28.Width = 1.098425!
        '
        'MSTRDATA29
        '
        Me.MSTRDATA29.CanGrow = False
        Me.MSTRDATA29.DataField = "MSTRDATA29"
        Me.MSTRDATA29.Height = 0.1692913!
        Me.MSTRDATA29.Left = 0.9578738!
        Me.MSTRDATA29.MultiLine = False
        Me.MSTRDATA29.Name = "MSTRDATA29"
        Me.MSTRDATA29.Style = "font-family: ＭＳ 明朝; font-size: 11pt; text-align: left; white-space: nowrap; ddo-c" &
            "har-set: 1"
        Me.MSTRDATA29.Tag = ""
        Me.MSTRDATA29.Text = "※仕入税額控除対象"
        Me.MSTRDATA29.Top = 0.2523622!
        Me.MSTRDATA29.Width = 1.098425!
        '
        'MSTRDATA26
        '
        Me.MSTRDATA26.CanGrow = False
        Me.MSTRDATA26.DataField = "MSTRDATA26"
        Me.MSTRDATA26.Height = 0.1692913!
        Me.MSTRDATA26.Left = 1.649213!
        Me.MSTRDATA26.MultiLine = False
        Me.MSTRDATA26.Name = "MSTRDATA26"
        Me.MSTRDATA26.Style = "font-family: ＭＳ 明朝; font-size: 9pt; text-align: left; white-space: nowrap; ddo-ch" &
            "ar-set: 1"
        Me.MSTRDATA26.Tag = ""
        Me.MSTRDATA26.Text = "■消費税課税対象外"
        Me.MSTRDATA26.Top = 0.2523622!
        Me.MSTRDATA26.Width = 1.767324!
        '
        'GroupHeader1
        '
        Me.GroupHeader1.Height = 0.0!
        Me.GroupHeader1.Name = "GroupHeader1"
        '
        'GroupFooter1
        '
        Me.GroupFooter1.Height = 0.001181364!
        Me.GroupFooter1.Name = "GroupFooter1"
        '
        'FRL501P15_J
        '
        Me.MasterReport = False
        Me.PageSettings.DefaultPaperSize = False
        Me.PageSettings.Margins.Bottom = 0.5511811!
        Me.PageSettings.Margins.Left = 0.3937007!
        Me.PageSettings.Margins.Right = 0.0!
        Me.PageSettings.Margins.Top = 0.1653543!
        Me.PageSettings.MirrorMargins = True
        Me.PageSettings.Orientation = GrapeCity.ActiveReports.Document.Section.PageOrientation.Portrait
        Me.PageSettings.PaperHeight = 11.69291!
        Me.PageSettings.PaperKind = GrapeCity.ActiveReports.Printing.PaperKind.A4
        Me.PageSettings.PaperWidth = 8.267716!
        Me.PrintWidth = 7.633598!
        Me.Sections.Add(Me.ReportHeader1)
        Me.Sections.Add(Me.PageHeader)
        Me.Sections.Add(Me.GroupHeader1)
        Me.Sections.Add(Me.Detail)
        Me.Sections.Add(Me.GroupFooter1)
        Me.Sections.Add(Me.PageFooter)
        Me.Sections.Add(Me.ReportFooter1)
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-style: normal; text-decoration: none; font-weight: normal; font-size: 10pt; " &
                    "color: Black; font-family: MS UI Gothic; ddo-char-set: 128", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-size: 16pt; font-weight: bold", "Heading1", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-size: 14pt; font-weight: bold", "Heading2", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-size: 13pt; font-weight: bold", "Heading3", "Normal"))
        CType(Me.MSTRDATA3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl001, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CGST, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl002, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ROOMNO, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl003, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PSN, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl004, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CIDATE, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl005, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CODATE, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl006, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl007, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl008, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl009, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl010, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl011, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MMDD, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EXPL, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RMNO, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CHRG, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CRDT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CHIT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NOTAXKBN, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MARK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SEPMARK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl012, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CHGSUM, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CRGSUM, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl013, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl014, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl015, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox36, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox37, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl028, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl128, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl016, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl017, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl018, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CNM, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ADDR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SEC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl101, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PRNTNM, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl021, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl022, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ISSUNO, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl023, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl200, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RECEIPTNM, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl024, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RECEIPTAMT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl025, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RECEIPTMEMO, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl026, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl027, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RECEIPTDATE, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BLNO, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PAYDATA, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl034, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl033, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PMINUS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EXPPOINT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl035, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PMINUS_E, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl035_E, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LNGCD, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl033_E, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EXPPOINT_E, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TITLESUMAMT1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TITLESUMAMT2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SUMAMT1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SUMAMT2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MARKSETUMEI, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl066, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl066_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PRTTAX1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PRTTAX2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl028_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HdLbl028_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TITLETAXNOT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TITLEOTHER, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SUMOTHERAMT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SUMTAXNOTAMT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA27, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA28, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSTRDATA26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub
    Private WithEvents ReportHeader1 As GrapeCity.ActiveReports.SectionReportModel.ReportHeader
    Private WithEvents ReportFooter1 As GrapeCity.ActiveReports.SectionReportModel.ReportFooter
    Private WithEvents GroupHeader1 As GrapeCity.ActiveReports.SectionReportModel.GroupHeader
    Private WithEvents GroupFooter1 As GrapeCity.ActiveReports.SectionReportModel.GroupFooter
    Private WithEvents HdLbl001 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents CGST As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl002 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents ROOMNO As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl003 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents PSN As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl004 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents CIDATE As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl005 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents CODATE As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl006 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents TextBox17 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl007 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl008 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl009 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl010 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl011 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents MMDD As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents EXPL As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents RMNO As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents CHRG As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents CRDT As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents CHIT As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl012 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents CHGSUM As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents CRGSUM As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl013 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents TextBox33 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl014 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl015 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents TextBox36 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents TextBox37 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl028 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl128 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl016 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl017 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl018 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents CNM As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents ADDR As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents SEC As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl101 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents PRNTNM As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl021 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl022 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents ISSUNO As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents Line4 As GrapeCity.ActiveReports.SectionReportModel.Line
    Private WithEvents HdLbl023 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl200 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents RECEIPTNM As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl024 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents RECEIPTAMT As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl025 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents RECEIPTMEMO As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl026 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl027 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents RECEIPTDATE As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents BLNO As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents PAYDATA As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents NOTAXKBN As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA3 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA2 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA1 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA4 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA5 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA6 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA7 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA8 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA9 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA10 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA11 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents Line5 As GrapeCity.ActiveReports.SectionReportModel.Line
    Friend WithEvents PageHeader As GrapeCity.ActiveReports.SectionReportModel.PageHeader
    Friend WithEvents MSTRDATA13 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA12 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents Line6 As GrapeCity.ActiveReports.SectionReportModel.Line
    Private WithEvents Line7 As GrapeCity.ActiveReports.SectionReportModel.Line
    Private WithEvents Line8 As GrapeCity.ActiveReports.SectionReportModel.Line
    Friend WithEvents PageFooter As GrapeCity.ActiveReports.SectionReportModel.PageFooter
    Private WithEvents Line9 As GrapeCity.ActiveReports.SectionReportModel.Line
    Private WithEvents Line2 As GrapeCity.ActiveReports.SectionReportModel.Line
    Private WithEvents Line1 As GrapeCity.ActiveReports.SectionReportModel.Line
    Private WithEvents HdLbl034 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl033 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents PMINUS As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents EXPPOINT As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl035 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents PMINUS_E As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl035_E As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents LNGCD As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl033_E As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents EXPPOINT_E As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents TITLESUMAMT1 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents TITLESUMAMT2 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents SUMAMT1 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents SUMAMT2 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents MARKSETUMEI As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents MARK As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents Shape1 As GrapeCity.ActiveReports.SectionReportModel.Shape
    Friend WithEvents TextBox1 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents TextBox3 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents SEPMARK As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl066 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl066_1 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents PRTTAX1 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents PRTTAX2 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl028_2 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents HdLbl028_1 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents TITLETAXNOT As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents TITLEOTHER As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents SUMOTHERAMT As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Private WithEvents SUMTAXNOTAMT As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA20 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA25 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA27 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA28 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA29 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA26 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA21 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA22 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA23 As GrapeCity.ActiveReports.SectionReportModel.TextBox
    Friend WithEvents MSTRDATA24 As GrapeCity.ActiveReports.SectionReportModel.TextBox
End Class
