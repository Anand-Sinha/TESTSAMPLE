﻿Partial Class FRL5010X
    Partial Class ItemHedDataTable

    End Class

End Class
