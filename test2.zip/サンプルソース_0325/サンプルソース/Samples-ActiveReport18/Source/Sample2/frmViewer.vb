﻿Imports System.Text
Imports Newtonsoft.Json
Imports System.IO
Imports GrapeCity.ActiveReports
Imports GrapeCity.ActiveReports.SectionReportModel
Imports GrapeCity.ActiveReports.Export.Xml.Section
Imports GrapeCity.ActiveReports.Document.Section
Imports GrapeCity.ActiveReports.Export.Pdf.Section

Public Class frmViewer

#Region "■■変数・定数設定■■"

    ''' 非表示列テータ
    ''' </summary>
    ''' <remarks></remarks>
    Private mHashControl As New Hashtable
    ''' <summary>
    ''' 非表示列テータ
    ''' </summary>
    ''' <remarks></remarks>
    Private mHashControlVisible As New Hashtable

#End Region

#Region "　□列挙体"
    ''' <summary>
    ''' ﾂｰﾙﾊﾞｰﾎﾞﾀﾝID
    ''' </summary>
    ''' <remarks></remarks>
    Private Enum mEnm_ToolIds
        ''' <summary>
        ''' EXPORTﾎﾞﾀﾝ
        ''' </summary>
        ''' <remarks></remarks>
        _EXPORT = 5002
    End Enum

#End Region

#Region "　□ﾌﾟﾛﾊﾟﾃｨ"
    ''' <summary>
    ''' 明細取得用ActiveReport
    ''' </summary>
    ''' <remarks></remarks>
    Private mReport As GrapeCity.ActiveReports.SectionReport
    Public Property PActiveReport() As GrapeCity.ActiveReports.SectionReport
        Get
            Return mReport
        End Get
        Set(ByVal value As GrapeCity.ActiveReports.SectionReport)
            mReport = value
        End Set
    End Property
#End Region


#Region "■■ｲﾍﾞﾝﾄ処理■■"

    ''' <summary>
    ''' ﾌｫｰﾑ起動時処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub xFrmRepView_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim btnExport As ToolStripButton

        Try
            btnExport = New ToolStripButton()

            btnExport.Name = "tsbExport"
            btnExport.Text = "エクスポート"
            ActItem_xViewer.Toolbar.ToolStrip.Items.Insert(2, btnExport)
            AddHandler btnExport.Click, AddressOf Me.ExportButtonClick

            '印刷プレビューした際に最大化で表示
            Me.WindowState = FormWindowState.Maximized

        Catch ex As Exception

        End Try

    End Sub

    ''' <summary>
    ''' ﾂｰﾙﾊﾞｰﾎﾞﾀﾝクリック処理
    ''' </summary>
    ''' <param name="sender">ﾂｰﾂﾊﾞｰﾎﾞﾀﾝ</param>
    ''' <param name="e">ｲﾍﾞﾝﾄ</param>
    ''' <remarks></remarks>

    Private Sub ExportButtonClick(ByVal sender As Object, ByVal e As System.EventArgs)

        'SaveFileDialogクラスのインスタンスを作成
        Dim dlgSave As New SaveFileDialog()
        Dim wClsPdfRepExport As PdfExport = Nothing
        Dim wMemoryStream As System.IO.MemoryStream = Nothing
        Dim wOptStream As System.IO.FileStream = Nothing

        Dim tsbSender As ToolStripItem = DirectCast(sender, ToolStripItem)
        ' ツールバーに追加したカスタムボタンの動作を処理します。
        Try
            Select Case (tsbSender.Name)
                Case "tsbExport"

                    ' レポートのエクスポート処理を呼び出します。
                    dlgSave.FileName = "tsbExport.csv"
                    dlgSave.InitialDirectory = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal)
                    '[ファイルの種類]に表示される選択肢を指定する
                    dlgSave.Filter = "PDFファイル(*.pdf)|*.pdf|CSVファイル(*.csv)|*.csv"

                    '[ファイルの種類]ではじめに
                    '「PDFのファイル」が選択されているようにする
                    dlgSave.FilterIndex = 1
                    'タイトルを設定する
                    dlgSave.Title = "保存先のファイルを選択してください"
                    'ダイアログボックスを閉じる前に現在のディレクトリを復元するようにする
                    dlgSave.RestoreDirectory = True
                    '既に存在するファイル名を指定したとき警告する
                    'デフォルトでTrueなので指定する必要はない
                    dlgSave.OverwritePrompt = True
                    '存在しないパスが指定されたとき警告を表示する
                    'デフォルトでTrueなので指定する必要はない
                    dlgSave.CheckPathExists = True

                    'ダイアログを表示する
                    If dlgSave.ShowDialog() = DialogResult.OK Then
                        Select Case dlgSave.FilterIndex
                            Case 1
                                LogHelper.LogInfo("PDFの出力開始")
                                wClsPdfRepExport = New PdfExport
                                wClsPdfRepExport.Export(ActItem_xViewer.Document, dlgSave.FileName)
                                LogHelper.LogInfo("PDFの出力終了")
                            Case 2
                                If mReport Is Nothing Then
                                    Dim wClsTxtRepExport As TextExport
                                    Dim wBytMid() As Byte
                                    Dim wStrMid As String = String.Empty
                                    Dim wBytOpt() As Byte
                                    wClsTxtRepExport = New TextExport
                                    wMemoryStream = New System.IO.MemoryStream
                                    wClsTxtRepExport.Encoding = System.Text.Encoding.GetEncoding("shift-jis")
                                    wClsTxtRepExport.SuppressEmptyLines = False
                                    wClsTxtRepExport.TextDelimiter = "\t"
                                    wClsTxtRepExport.Export(ActItem_xViewer.Document, wMemoryStream)
                                    wBytMid = wMemoryStream.ToArray
                                    wMemoryStream.Flush()
                                    wMemoryStream.Close()
                                    wMemoryStream = Nothing
                                    wStrMid = System.Text.Encoding.GetEncoding("shift-jis").GetString(wBytMid)

                                    wStrMid = FncReplace(wStrMid, vbCrLf & vbCrLf, vbCrLf)
                                    wStrMid = FncReplace(wStrMid, "\t", """" & "\t" & """")
                                    wStrMid = FncReplace(wStrMid, vbCrLf, """" & vbCrLf & """")
                                    wStrMid = FncReplace(wStrMid, """" & """", """" & " " & """")
                                    wStrMid = wStrMid.Remove(wStrMid.LastIndexOf(""""), 1)
                                    wStrMid = """" & wStrMid
                                    wStrMid = FncReplace(wStrMid, "\t", ",")

                                    wBytOpt = System.Text.Encoding.GetEncoding("shift-jis").GetBytes(wStrMid)
                                    If System.IO.File.Exists(dlgSave.FileName) Then
                                        wOptStream = New System.IO.FileStream(dlgSave.FileName, IO.FileMode.Truncate)
                                    Else
                                        wOptStream = New System.IO.FileStream(dlgSave.FileName, IO.FileMode.CreateNew)
                                    End If

                                    wOptStream.Write(wBytOpt, 0, wBytOpt.Length)
                                    wOptStream.Flush()
                                    wOptStream.Close()
                                    wOptStream = Nothing

                                Else
                                    Dim report As New SectionReport
                                    Call SubSetRptDetail(report)

                                    mReport.Restart()
                                    mReport.DataSource = report.DataSource
                                    mReport.DataMember = report.DataMember

                                    '非_MainTBL、_SubTBLのテーブルは、コントロルを値を設定処理を行う
                                    Dim wAddFlg As Boolean = True
                                    Dim wTableName As String = String.Empty
                                    For i As Integer = 0 To CType(mReport.DataSource, DataSet).Tables.Count - 1

                                        wTableName = CType(mReport.DataSource, DataSet).Tables(i).TableName

                                        If wTableName = mReport.DataMember Then
                                            Continue For
                                        End If

                                        If wAddFlg AndAlso CType(mReport.DataSource, DataSet).Tables(i).Rows.Count = 1 Then
                                            Me.SubSetUnboundField(mReport, CType(mReport.DataSource, DataSet), wTableName)
                                            Me.SubSetUnboundData(mReport, CType(mReport.DataSource, DataSet), wTableName)
                                        End If
                                        wAddFlg = True
                                    Next

                                    For Each Item As GrapeCity.ActiveReports.SectionReportModel.Section In mReport.Sections
                                        If Item.Type <> SectionType.Detail AndAlso
                                            Item.Type <> SectionType.GroupHeader AndAlso
                                             Item.Type <> SectionType.GroupFooter Then
                                            AddHandler Item.BeforePrint, AddressOf Header_BeforePrint
                                        Else

                                            If Item.Tag = "1" Then
                                                Item.Visible = True
                                            End If

                                            AddHandler Item.BeforePrint, AddressOf Detail_BeforePrint
                                            AddHandler Item.AfterPrint, AddressOf Detail_AfterPrint
                                        End If
                                    Next

                                    mReport.Run()
                                    Me.Close()


                                    Dim wClsTxtRepExport As TextExport
                                    Dim wBytMid() As Byte
                                    Dim wStrMid As String = String.Empty
                                    Dim wBytOpt() As Byte
                                    wClsTxtRepExport = New TextExport
                                    wMemoryStream = New System.IO.MemoryStream
                                    wClsTxtRepExport.Encoding = System.Text.Encoding.GetEncoding("shift-jis")
                                    wClsTxtRepExport.SuppressEmptyLines = False
                                    wClsTxtRepExport.TextDelimiter = "\t"
                                    wClsTxtRepExport.Export(mReport.Document, wMemoryStream)
                                    wBytMid = wMemoryStream.ToArray
                                    wMemoryStream.Flush()
                                    wMemoryStream.Close()
                                    wMemoryStream = Nothing
                                    wStrMid = System.Text.Encoding.GetEncoding("shift-jis").GetString(wBytMid)

                                    wStrMid = FncReplace(wStrMid, vbCrLf & vbCrLf, vbCrLf)
                                    wStrMid = FncReplace(wStrMid, "\t", """" & "\t" & """")
                                    wStrMid = FncReplace(wStrMid, vbCrLf, """" & vbCrLf & """")
                                    wStrMid = FncReplace(wStrMid, """" & """", """" & " " & """")
                                    wStrMid = wStrMid.Remove(wStrMid.LastIndexOf(""""), 1)
                                    wStrMid = """" & wStrMid
                                    wStrMid = FncReplace(wStrMid, "\t", ",")

                                    wBytOpt = System.Text.Encoding.GetEncoding("shift-jis").GetBytes(wStrMid)

                                    If System.IO.File.Exists(dlgSave.FileName) Then
                                        wOptStream = New System.IO.FileStream(dlgSave.FileName, IO.FileMode.Truncate)
                                    Else
                                        wOptStream = New System.IO.FileStream(dlgSave.FileName, IO.FileMode.CreateNew)
                                    End If

                                    wOptStream.Write(wBytOpt, 0, wBytOpt.Length)
                                    wOptStream.Flush()
                                    wOptStream.Close()
                                    wOptStream = Nothing

                                End If
                        End Select
                    End If
            End Select
        Catch ex As Exception

        Finally
            If wMemoryStream IsNot Nothing Then
                wMemoryStream.Close()
                wMemoryStream = Nothing
            End If
            If wOptStream IsNot Nothing Then
                wOptStream.Close()
                wOptStream = Nothing
            End If
        End Try

    End Sub

    ''' <summary>
    ''' 帳票明細作成
    ''' </summary>
    ''' <param name="rReport">帳票明細作成用ﾚﾎﾟｰﾄ</param>
    ''' <remarks></remarks>
    Private Sub SubSetRptDetail(rReport As GrapeCity.ActiveReports.SectionReport)

        rReport = Activator.CreateInstance(mReport.GetType(), True)
        rReport.DataSource = mReport.DataSource
        rReport.DataMember = mReport.DataMember
        mReport = rReport
    End Sub

    ''' <summary>
    ''' 非表示列テータ処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Detail_BeforePrint(ByVal sender As Object, ByVal e As System.EventArgs)

        Dim detail As GrapeCity.ActiveReports.SectionReportModel.Section = sender
        If detail.Height > 0.0! Then
            For Each control As ARControl In detail.Controls
                If String.IsNullOrEmpty(control.DataField) Then
                    Select Case control.GetType.Name
                        Case GetType(GrapeCity.ActiveReports.SectionReportModel.TextBox).Name
                            Dim wCtrlTxtBox As GrapeCity.ActiveReports.SectionReportModel.TextBox = CType(control, GrapeCity.ActiveReports.SectionReportModel.TextBox)
                            Me.mHashControl.Add(wCtrlTxtBox.Name, wCtrlTxtBox.Text)
                        Case GetType(GrapeCity.ActiveReports.SectionReportModel.Label).Name
                            Dim wCtrlLbl As GrapeCity.ActiveReports.SectionReportModel.Label = CType(control, GrapeCity.ActiveReports.SectionReportModel.Label)
                            Me.mHashControl.Add(wCtrlLbl.Name, wCtrlLbl.Text)
                    End Select
                End If
            Next

            For Each control As ARControl In detail.Controls
                If control.Visible = False Then
                    mHashControlVisible.Add(control.Name, control)
                    Select Case control.GetType.Name
                        Case GetType(GrapeCity.ActiveReports.SectionReportModel.TextBox).Name
                            Dim wCtrlTxtBox As GrapeCity.ActiveReports.SectionReportModel.TextBox = CType(control, GrapeCity.ActiveReports.SectionReportModel.TextBox)
                            wCtrlTxtBox.Text = " "
                            wCtrlTxtBox.Value = " "
                        Case GetType(GrapeCity.ActiveReports.SectionReportModel.Label).Name
                            Dim wCtrlLbl As GrapeCity.ActiveReports.SectionReportModel.Label = CType(control, GrapeCity.ActiveReports.SectionReportModel.Label)
                            wCtrlLbl.Text = " "
                            wCtrlLbl.Value = " "

                        Case GetType(GrapeCity.ActiveReports.SectionReportModel.SubReport).Name
                            If CType(control, GrapeCity.ActiveReports.SectionReportModel.SubReport).Report IsNot Nothing Then
                                For Each Item As GrapeCity.ActiveReports.SectionReportModel.Section In CType(control, GrapeCity.ActiveReports.SectionReportModel.SubReport).Report.Sections
                                    AddHandler Item.BeforePrint, AddressOf Detail_BeforePrint
                                    AddHandler Item.AfterPrint, AddressOf Detail_AfterPrint
                                Next
                            End If
                    End Select
                    control.Visible = True
                Else
                    Select Case control.GetType.Name
                        Case GetType(GrapeCity.ActiveReports.SectionReportModel.TextBox).Name
                            Dim wCtrlTxtBox As GrapeCity.ActiveReports.SectionReportModel.TextBox = CType(control, GrapeCity.ActiveReports.SectionReportModel.TextBox)
                            If String.IsNullOrEmpty(control.DataField) Then
                                wCtrlTxtBox.Text = mHashControl(wCtrlTxtBox.Name)
                                wCtrlTxtBox.Value = mHashControl(wCtrlTxtBox.Name)
                            End If
                        Case GetType(GrapeCity.ActiveReports.SectionReportModel.Label).Name
                            Dim wCtrlLbl As GrapeCity.ActiveReports.SectionReportModel.Label = CType(control, GrapeCity.ActiveReports.SectionReportModel.Label)
                            If String.IsNullOrEmpty(control.DataField) Then
                                wCtrlLbl.Text = mHashControl(wCtrlLbl.Name)
                                wCtrlLbl.Value = mHashControl(wCtrlLbl.Name)
                            End If
                        Case GetType(GrapeCity.ActiveReports.SectionReportModel.SubReport).Name
                            If CType(control, GrapeCity.ActiveReports.SectionReportModel.SubReport).Report IsNot Nothing Then
                                For Each Item As GrapeCity.ActiveReports.SectionReportModel.Section In CType(control, GrapeCity.ActiveReports.SectionReportModel.SubReport).Report.Sections
                                    AddHandler Item.BeforePrint, AddressOf Detail_BeforePrint
                                    AddHandler Item.AfterPrint, AddressOf Detail_AfterPrint
                                Next
                            End If
                    End Select
                End If
            Next
            Me.mHashControl.Clear()
        End If
    End Sub

    ''' <summary>
    ''' 非表示列テータAfterPrint処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Detail_AfterPrint(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim wEnumerator As System.Collections.IDictionaryEnumerator = mHashControlVisible.GetEnumerator()
        Dim detail As GrapeCity.ActiveReports.SectionReportModel.Section = sender

        If detail.Tag = "1" Then
            detail.Visible = False
        End If

        While (wEnumerator.MoveNext)
            Select Case mHashControlVisible.Item(wEnumerator.Key.ToString).GetType.Name
                Case GetType(GrapeCity.ActiveReports.SectionReportModel.TextBox).Name
                    Dim wCtrlTxtBox As GrapeCity.ActiveReports.SectionReportModel.TextBox = CType(mHashControlVisible.Item(wEnumerator.Key.ToString), GrapeCity.ActiveReports.SectionReportModel.TextBox)
                    wCtrlTxtBox.Visible = False
                Case GetType(GrapeCity.ActiveReports.SectionReportModel.Label).Name
                    Dim wCtrlLbl As GrapeCity.ActiveReports.SectionReportModel.Label = CType(mHashControlVisible.Item(wEnumerator.Key.ToString), GrapeCity.ActiveReports.SectionReportModel.Label)
                    wCtrlLbl.Visible = False
            End Select
        End While
        mHashControlVisible.Clear()
    End Sub

    ''' <summary>
    ''' CSV出力の非表示項目設定処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Header_BeforePrint(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim detail As GrapeCity.ActiveReports.SectionReportModel.Section = sender
        For Each control As ARControl In detail.Controls
            control.Visible = False
        Next
    End Sub

    ''' <summary>
    ''' ﾍｯﾀﾞｰ部のフィールドを追加
    ''' </summary>
    ''' <param name="pDstRpt">
    ''' データセット
    ''' </param>
    ''' <param name="pStrHedTbl">
    ''' データテーブル名
    ''' </param>
    ''' <remarks></remarks>
    Protected Overridable Sub SubSetUnboundField(rClsRpt As GrapeCity.ActiveReports.SectionReport, ByRef pDstRpt As DataSet, ByVal pStrHedTbl As String)

        Dim wDtbHeader As DataTable

        '■■ヘッダデータ設定処理
        wDtbHeader = pDstRpt.Tables(pStrHedTbl)

        For Each wDtbCol As DataColumn In wDtbHeader.Columns
            rClsRpt.Fields.Add(wDtbCol.ColumnName)
        Next

    End Sub
    ''' <summary>
    ''' ﾍｯﾀﾞｰ部のフィールドに値を設定処理を行う
    ''' </summary>
    ''' <param name="pDstRpt">
    ''' データセット
    ''' </param>
    ''' <param name="pStrHedTbl">
    ''' データテーブル名
    ''' </param>
    ''' <remarks></remarks>
    Protected Overridable Sub SubSetUnboundData(rClsRpt As GrapeCity.ActiveReports.SectionReport, ByRef pDstRpt As DataSet, ByVal pStrHedTbl As String)

        Dim wDtbHeader As DataTable

        '■■ヘッダデータ設定処理
        wDtbHeader = pDstRpt.Tables(pStrHedTbl)

        For Each wDtbCol As DataColumn In wDtbHeader.Columns
            rClsRpt.Fields(wDtbCol.ColumnName).Value = wDtbHeader.Rows(0)(wDtbCol.ColumnName)
        Next

    End Sub

    Public Function FncReplace(ByVal pStrTarget As String _
                       , ByVal pStrOld As String _
                       , ByVal pStrNew As String) As String
        Try
            '■■引数のNothingを無くす
            pStrTarget &= "" : pStrOld &= "" : pStrNew &= ""

            '■■置換元が""の場合、変更無し
            If String.IsNullOrEmpty(pStrOld) = True Then Return pStrTarget

            '■■置換
            Return pStrTarget.Replace(pStrOld, pStrNew)
        Catch ex As Exception
            Return ""
        End Try
    End Function
#End Region

End Class