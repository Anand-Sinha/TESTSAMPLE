﻿Imports GrapeCity.ActiveReports.Document
Imports GrapeCity.ActiveReports.Document.Section
Imports GrapeCity.ActiveReports.SectionReportModel
Imports GrapeCity.ActiveReports.Controls
Imports GrapeCity.ActiveReports


Imports System.Drawing.Imaging

Public Class SampleReport1
    Private Sub SampleReport1_PageStart(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PageStart
        Dim wPageRowCnt As Integer
        wPageRowCnt = CType(CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("PAGEROWCNT"), Integer)
        If Me.PageNumber = (CType(Me.DataSource, FRL5010X).FRL5010R.Rows.Count + wPageRowCnt - 1) \ wPageRowCnt Then
            PageFooter.Height = 0
            PageFooter.Visible = False
        End If
    End Sub

    Private Sub PageFooter_Format(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PageFooter.Format
        Dim wintline As Integer
        wintline = CType(CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("PAGEROWCNT"), Integer)
        Dim wDecChg As Decimal = 0
        Dim wDecCrg As Decimal = 0
        Dim i As Integer = 0
        For i = wintline * (Me.PageNumber - 1) To wintline * Me.PageNumber - 1
            Dim wDtr As DataRow = CType(Me.DataSource, FRL5010X).FRL5010R.Rows(i)

            If wDtr.Item("CHRG").Equals(DBNull.Value) = False Then
                wDecChg += CType(wDtr.Item("CHRG"), Decimal)
            End If

            If wDtr.Item("CRDT").Equals(DBNull.Value) = False Then
                wDecCrg += CType(wDtr.Item("CRDT"), Decimal)
            End If
        Next

        CHGSUM.Value = wDecChg
        CRGSUM.Value = wDecCrg

    End Sub

    Private Sub ReportFooter1_Format(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReportFooter1.Format

        If CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("PRTKBN").Equals(DBNull.Value) = False Then
            If CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("PRTKBN").ToString = "9" Then
                HdLbl014.Visible = False
                TextBox36.Visible = False
                HdLbl028.Visible = False
            End If
        End If

        If CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("FTAX").Equals(DBNull.Value) = False Then
            If CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("FTAX").ToString <> "1" Then
                HdLbl015.Visible = False
                TextBox37.Visible = False
                HdLbl128.Visible = False
            End If
        End If

        If Not String.IsNullOrEmpty(CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("RECEIPTDATE").ToString()) Then
            HdLbl027.Visible = False
        End If

        Dim p As System.Drawing.PointF
        If CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("INVSETFLG").ToString = "1" Then
            If CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("SUMAMT1").ToString = "0" Then
                Me.TITLESUMAMT1.Visible = False
                Me.SUMAMT1.Visible = False
                Me.HdLbl066.Visible = False
                Me.PRTTAX1.Visible = False
                Me.HdLbl028_1.Visible = False
            End If
            If CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("SUMAMT2").ToString = "0" Then
                Me.TITLESUMAMT2.Visible = False
                Me.SUMAMT2.Visible = False
                Me.HdLbl066_1.Visible = False
                Me.PRTTAX2.Visible = False
                Me.HdLbl028_2.Visible = False
            End If
            If CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("SUMTAXNOTAMT").ToString = "0" Then
                Me.TITLETAXNOT.Visible = False
                Me.SUMTAXNOTAMT.Visible = False
            End If
            If CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("SUMOTHERAMT").ToString = "0" Then
                Me.TITLEOTHER.Visible = False
                Me.SUMOTHERAMT.Visible = False
            End If
            If CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("TAXKBN1").ToString = "3" OrElse CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("TAXKBN1").ToString = "4" Then
                Me.HdLbl066.Visible = False
                Me.PRTTAX1.Visible = False
                Me.HdLbl028_1.Visible = False

                p.X = 6.602362!
                p.Y = 0.2086614!
                Me.SUMAMT1.Location = p
            End If
            If CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("TAXKBN2").ToString = "3" OrElse CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("TAXKBN2").ToString = "4" Then
                Me.HdLbl066_1.Visible = False
                Me.PRTTAX2.Visible = False
                Me.HdLbl028_2.Visible = False

                p.X = 6.602362!
                p.Y = 0.3858268!
                Me.SUMAMT2.Location = p
            End If
            If CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("TAXKBN1").ToString = "2" Then
                If CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("SUMAMT2").ToString = "0" Then
                    p.X = 5.57874!
                    p.Y = 0.3858268!
                    Me.MARKSETUMEI.Location = p
                ElseIf CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("SUMTAXNOTAMT").ToString = "0" Then
                    p.X = 5.57874!
                    p.Y = 0.5629921!
                    Me.MARKSETUMEI.Location = p
                ElseIf CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("SUMOTHERAMT").ToString = "0" Then
                    p.X = 5.57874!
                    p.Y = 0.7440945!
                    Me.MARKSETUMEI.Location = p
                End If
            ElseIf CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("TAXKBN2").ToString = "2" Then
                If CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("SUMTAXNOTAMT").ToString = "0" Then
                    p.X = 5.57874!
                    p.Y = 0.5629921!
                    Me.MARKSETUMEI.Location = p
                ElseIf CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("SUMOTHERAMT").ToString = "0" Then
                    p.X = 5.57874!
                    p.Y = 0.7440945!
                    Me.MARKSETUMEI.Location = p
                End If
            End If
        Else
            Me.HdLbl066.Visible = False
            Me.HdLbl066_1.Visible = False
            Me.HdLbl028_1.Visible = False
            Me.HdLbl028_2.Visible = False
        End If
    End Sub

    Private Sub SampleReport1_ReportStart(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.ReportStart
        Dim myMemory As System.IO.MemoryStream = Nothing
        Dim mImgFloor As Image = Nothing
        Try
            Me.ResetWatermark()
            'LOGO画像の表示処理
            Dim wStrLogoImg As String = CType(CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("LOGOIMG"), String)
            If Me.Fields("LOGO").Value IsNot Nothing Then
                Dim wBytImg() As Byte = CType(Me.Fields("LOGO").Value, Byte())
                myMemory = New System.IO.MemoryStream(wBytImg, 0, wBytImg.Length)
                mImgFloor = Image.FromStream(myMemory)
                Me.Watermark = mImgFloor
                Me.WatermarkAlignment = PictureAlignment.TopLeft
                If Not ImageFormat.Png.ToString().Equals(Me.Watermark.RawFormat.ToString()) Then
                    Me.WatermarkSizeMode = SizeModes.Stretch

                End If
            Else
                Me.Watermark = Nothing
            End If
        Catch ex As Exception
            If mImgFloor IsNot Nothing Then
                mImgFloor.Dispose()
                mImgFloor = Nothing
            End If
            Throw ex
        Finally
            If myMemory IsNot Nothing Then
                myMemory.Close()
                myMemory = Nothing
            End If
        End Try

        Dim wStrSTLCLSCD As String = CType(CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("STLCLSCD"), String)
        Dim wStrLangID As String = CType(CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("LANGID"), String)

        Me.HdLbl016.Visible = False
        Me.HdLbl017.Visible = False
        Me.HdLbl018.Visible = False
        Me.HdLbl101.Visible = False
        Me.CNM.Width = 6.251182!
        Me.ADDR.Width = 3.768898!


        If CBool(CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("VISIBLEFLG")) = False Then
            HdLbl033.Visible = False
            HdLbl034.Visible = False
            HdLbl035.Visible = False
            PMINUS.Visible = False
            EXPPOINT.Visible = False
            HdLbl033_E.Visible = False
            HdLbl035_E.Visible = False
            PMINUS_E.Visible = False
            EXPPOINT_E.Visible = False
        Else
            If wStrLangID = "J" Then
                HdLbl033.Visible = True
                HdLbl034.Visible = True
                HdLbl035.Visible = True
                PMINUS.Visible = True
                EXPPOINT.Visible = True
                HdLbl035_E.Visible = False
                HdLbl033_E.Visible = False
                PMINUS_E.Visible = False
                EXPPOINT_E.Visible = False
            Else

                HdLbl033_E.Visible = True
                HdLbl035_E.Visible = True
                PMINUS_E.Visible = True
                EXPPOINT.Visible = True
                HdLbl033.Visible = False
                HdLbl034.Visible = False
                HdLbl035.Visible = False
                PMINUS.Visible = False
                EXPPOINT_E.Visible = False
            End If
        End If

        Dim wStrInvsetFlg As String = CType(CType(Me.DataSource, FRL5010X).ItemHed.Rows(0).Item("INVSETFLG"), String)
        If wStrInvsetFlg <> "1" Then
            Dim p As System.Drawing.PointF
            p.X = 3.68110251!
            p.Y = 0.3858268!
            Me.TITLESUMAMT1.Location = p
            p.X = 6.602362!
            p.Y = 0.3858268!
            Me.SUMAMT1.Location = p
            p.X = 3.68110251!
            p.Y = 0.5629921!
            Me.TITLESUMAMT2.Location = p
            p.X = 6.602362!
            p.Y = 0.5629921!
            Me.SUMAMT2.Location = p
            p.X = 5.57874!
            p.Y = 0.7440945!
            Me.MARKSETUMEI.Location = p
        End If
    End Sub
End Class
