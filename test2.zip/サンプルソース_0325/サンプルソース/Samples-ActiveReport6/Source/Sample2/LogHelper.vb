﻿Imports System.IO

Public Class LogHelper
    ' 日志级别枚举
    Public Enum LogLevel
        Info
        Warning
        [Error] ' 此处使用方括号使枚举支持关键字
    End Enum

    ' 日志文件路径
    Private Shared LogFilePath As String = "log.txt"

    ' 是否启用控制台输出
    Private Shared EnableConsoleOutput As Boolean = True

    Private Shared LogTextControl As System.Windows.Forms.TextBox = Nothing

    ' 设置日志文件路径
    Public Shared Sub SetLogFilePath(filePath As String)
        LogFilePath = filePath
    End Sub

    ' 启用或禁用控制台输出
    Public Shared Sub SetConsoleOutput(enable As Boolean)
        EnableConsoleOutput = enable
    End Sub

    Public Shared Sub SetLogTextControl(textControl As System.Windows.Forms.TextBox)
        LogTextControl = textControl
    End Sub

    ' 写入日志
    Public Shared Sub WriteLog(ByVal level As LogLevel, ByVal message As String)
        ''$"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff} [{level.ToString}] {message}"
        Dim logMessage As String = String.Format("{0} [{1}] {2}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"), level.ToString, message)

        ' 写入到文件
        WriteLogToFile(logMessage)

        ' 输出到控制台
        If EnableConsoleOutput Then
            WriteLogToConsole(logMessage)
        End If

        If LogTextControl IsNot Nothing Then
            LogTextControl.AppendText(logMessage)
            LogTextControl.AppendText(Environment.NewLine)
        End If
    End Sub

    ' 写入到文件
    Private Shared Sub WriteLogToFile(message As String)
        Try
            ' 追加写入日志到文件
            Using writer As StreamWriter = New StreamWriter(LogFilePath, True)
                writer.WriteLine(message)
            End Using
        Catch ex As Exception
            ' 如果写入文件失败，可以在这里处理异常
            'Console.WriteLine($"[Error] Failed to write log to file: {ex.Message}")
            Console.WriteLine(String.Format("[Error] Failed to write log to file: {0}", ex.Message))
        End Try
    End Sub

    ' 输出到控制台
    Private Shared Sub WriteLogToConsole(message As String)
        Console.WriteLine(message)
    End Sub

    ' 快捷方法：写 Info 日志
    Public Shared Sub LogInfo(message As String)
        WriteLog(LogLevel.Info, message)
    End Sub

    ' 快捷方法：写 Warning 日志
    Public Shared Sub LogWarning(message As String)
        WriteLog(LogLevel.Warning, message)
    End Sub

    ' 快捷方法：写 Error 日志
    Public Shared Sub LogError(message As String)
        WriteLog(LogLevel.Error, message)
    End Sub
End Class
