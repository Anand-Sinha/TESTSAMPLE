﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmViewer
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ActItem_xViewer = New DataDynamics.ActiveReports.Viewer.Viewer
        Me.SuspendLayout()
        '
        'ActItem_xViewer
        '
        Me.ActItem_xViewer.BackColor = System.Drawing.SystemColors.Control
        Me.ActItem_xViewer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ActItem_xViewer.Document = New DataDynamics.ActiveReports.Document.Document("ARNet Document")
        Me.ActItem_xViewer.Location = New System.Drawing.Point(0, 0)
        Me.ActItem_xViewer.Name = "ActItem_xViewer"
        Me.ActItem_xViewer.ReportViewer.CurrentPage = 0
        Me.ActItem_xViewer.ReportViewer.MultiplePageCols = 3
        Me.ActItem_xViewer.ReportViewer.MultiplePageRows = 2
        Me.ActItem_xViewer.ReportViewer.ViewType = DataDynamics.ActiveReports.Viewer.ViewType.Normal
        Me.ActItem_xViewer.Size = New System.Drawing.Size(998, 592)
        Me.ActItem_xViewer.TabIndex = 0
        Me.ActItem_xViewer.TableOfContents.Text = "Table Of Contents"
        Me.ActItem_xViewer.TableOfContents.Width = 200
        Me.ActItem_xViewer.TabTitleLength = 35
        Me.ActItem_xViewer.Toolbar.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        '
        'xFrmRepView
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(998, 592)
        Me.Controls.Add(Me.ActItem_xViewer)
        Me.Name = "xFrmRepView"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Public WithEvents ActItem_xViewer As DataDynamics.ActiveReports.Viewer.Viewer

End Class
